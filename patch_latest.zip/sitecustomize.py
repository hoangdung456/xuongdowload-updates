import os
import sys

try:
    log_path = os.path.join(os.environ.get("APPDATA", ""), "sitecustomize.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(f"[{os.getpid()}] sitecustomize loaded in {sys.executable} (argv: {sys.argv})\n")
except Exception:
    pass

try:
    import bili_patch
    bili_patch.install_patch()
except Exception as e:
    try:
        log_path = os.path.join(os.environ.get("APPDATA", ""), "sitecustomize.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{os.getpid()}] error importing bili_patch: {e}\n")
    except Exception:
        pass
