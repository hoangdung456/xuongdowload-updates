import os
import sys

# Only run in production environment where reup_studio is present
app_pkg = os.path.join(os.path.dirname(__file__), "reup_studio")
if not os.path.isdir(app_pkg):
    pass
else:
    try:
        log_path = os.path.join(os.environ.get("APPDATA", ""), "sitecustomize.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{os.getpid()}] sitecustomize loaded in {sys.executable}\n")
    except Exception:
        pass

    try:
        import bili_patch
        bili_patch.install_patch()
    except Exception as e:
        pass



