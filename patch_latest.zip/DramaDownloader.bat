@echo off
title Drama Downloader Pro
cd /d "%~dp0"
call "%~dp0Tai_Phim_Ngan_Drama.bat"
