#!/usr/bin/env python3
"""
ReupStudio Local Bridge & Mock Service
- Handles HTTPS interception for rpa.momigo.ai (mocking license & proxy APIs)
- Bridges Hongguo/Netshort scraping directly to unidbg-sign & Hongguo Downloader engine
- Passthrough tunneling for all other web and video traffic (Douyin, TikTok, YouTube, Bilibili, etc.)
"""

import sys
import os
import json
import base64
import time
import socket
import ssl
import select
import threading
import urllib.parse
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
import encodings.idna
import encodings.utf_8
import encodings.ascii
import encodings.latin_1
import subprocess
import shutil

# DNS resolution patch for Bilibili to bypass ISP DNS drop/poisoning
_orig_getaddrinfo = socket.getaddrinfo
def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    try:
        return _orig_getaddrinfo(host, port, family, type, proto, flags)
    except Exception:
        if host == "api.bilibili.tv":
            return _orig_getaddrinfo("164.52.1.60", port, family, type, proto, flags)
        if host == "www.bilibili.tv":
            return _orig_getaddrinfo("156.59.137.23", port, family, type, proto, flags)
        raise
socket.getaddrinfo = _patched_getaddrinfo

# Set up paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
engine_dir = os.path.join(BASE_DIR, "engine", "python")
if sys.version_info[:2] == (3, 11) and os.path.exists(engine_dir):
    sys.path = [p for p in sys.path if os.path.abspath(p) != os.path.abspath(BASE_DIR)]
    if engine_dir not in sys.path:
        sys.path.insert(0, engine_dir)
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)
import license_manager
CERT_DIR = os.path.join(BASE_DIR, "certs")
LOCAL_ENGINE = os.path.join(BASE_DIR, "engine")

LOCALAPPDATA = os.environ.get("LOCALAPPDATA", "")
FALLBACK_DIR = os.path.join(LOCALAPPDATA, "Programs", "Hongguo Downloader") if LOCALAPPDATA else ""
def get_hg_python():
    cands = [
        os.path.join(LOCAL_ENGINE, "python", "python.exe"),
        os.path.join(BASE_DIR, "engine", "python", "python.exe"),
        os.path.join(BASE_DIR, "python.exe"),
        sys.executable,
        os.path.join(FALLBACK_DIR, "python", "python.exe") if FALLBACK_DIR else "",
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return shutil.which("python") or "python"

def get_hg_java():
    cands = [
        os.path.join(LOCAL_ENGINE, "jre", "bin", "java.exe"),
        os.path.join(BASE_DIR, "engine", "jre", "bin", "java.exe"),
        os.path.join(FALLBACK_DIR, "jre", "bin", "java.exe") if FALLBACK_DIR else "",
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return shutil.which("java") or "java"

def get_hg_sign_jar():
    cands = [
        os.path.join(LOCAL_ENGINE, "app", "sign", "unidbg-sign.jar"),
        os.path.join(BASE_DIR, "engine", "app", "sign", "unidbg-sign.jar"),
        os.path.join(FALLBACK_DIR, "app", "sign", "unidbg-sign.jar") if FALLBACK_DIR else "",
    ]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return ""

HG_PYTHON = get_hg_python()
HG_JAVA = get_hg_java()
HG_SIGN_JAR = get_hg_sign_jar()

os.environ["SIGN_SERVER"] = "http://127.0.0.1:9099"
os.environ["HG_SIGN_TOKEN"] = "secret123"

PROXY_PORT = 8765

def log(msg):
    try:
        sys.stdout.buffer.write(f"[Bridge] {msg}\n".encode("utf-8", "replace"))
        sys.stdout.buffer.flush()
    except Exception:
        try:
            print(f"[Bridge] {str(msg).encode('ascii', 'replace').decode('ascii')}", flush=True)
        except Exception:
            pass

# 1. Ensure unidbg signer is running on 9099
def ensure_signer():
    try:
        s = socket.socket()
        s.settimeout(1.0)
        s.connect(("127.0.0.1", 9099))
        s.close()
        log("Unidbg signer is already running on port 9099.")
        return
    except Exception:
        pass

    log("Starting Unidbg signer on port 9099...")
    java_exe = get_hg_java()
    sign_jar = get_hg_sign_jar()
    if not os.path.exists(java_exe) or not os.path.exists(sign_jar):
        log(f"Signer prerequisites missing: java={java_exe}, jar={sign_jar}")
        return

    cmd = [
        java_exe,
        "-Xmx1024m",
        "-XX:+ExitOnOutOfMemoryError",
        "--add-opens",
        "java.base/java.lang=ALL-UNNAMED",
        "-cp",
        sign_jar,
        "com.hongguo.sign.FqTrace",
        "serve",
        "9099"
    ]
    env = dict(os.environ)
    env["HG_SIGN_TOKEN"] = "secret123"
    subprocess.Popen(
        cmd,
        cwd=os.path.dirname(sign_jar) if os.path.exists(os.path.dirname(sign_jar)) else BASE_DIR,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=0x08000000 if sys.platform == "win32" else 0
    )
    for _ in range(15):
        time.sleep(1)
        try:
            s = socket.socket()
            s.settimeout(1.0)
            s.connect(("127.0.0.1", 9099))
            s.close()
            log("Unidbg signer is now up on port 9099!")
            return
        except Exception:
            pass
    log("Warning: Unidbg signer did not respond on port 9099.")

# 2. Hongguo Scraper Client using subprocess
def call_hongguo_action(action, params):
    ensure_signer()
    py_exe = get_hg_python()
    helper_script = os.path.join(BASE_DIR, "hg_worker.pyc") if os.path.exists(os.path.join(BASE_DIR, "hg_worker.pyc")) else os.path.join(BASE_DIR, "hg_worker.py")
    req_json = json.dumps({"action": action, "params": params})
    proc_env = dict(os.environ)
    proc_env["PYTHONIOENCODING"] = "utf-8"
    proc_env["PYTHONUTF8"] = "1"
    proc = subprocess.run(
        [py_exe, helper_script],
        input=req_json,
        text=True,
        capture_output=True,
        encoding="utf-8",
        env=proc_env,
        cwd=os.path.dirname(py_exe) if os.path.exists(os.path.dirname(py_exe)) else BASE_DIR,
        creationflags=0x08000000 if sys.platform == "win32" else 0
    )
    if proc.returncode == 0 and proc.stdout.strip():
        raw_out = proc.stdout.strip()
        start_idx = raw_out.find('{')
        end_idx = raw_out.rfind('}')
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            try:
                return json.loads(raw_out[start_idx:end_idx + 1])
            except Exception as e:
                log(f"JSON slice parse error: {e}")
        try:
            return json.loads(raw_out)
        except Exception as e:
            log(f"JSON parse error from worker: {e}, output: {raw_out[:200]}")
    else:
        log(f"Worker failed: code {proc.returncode}, stderr: {proc.stderr[:300]}")
    return {"ok": False, "message": "Worker error"}

def call_netshort_grab(params):
    helper_script = os.path.join(BASE_DIR, "netshort_helper.js")
    film_id = str(params.get("id") or params.get("series_id") or "")
    limit = int(params.get("limit") or 0)
    log(f"Handling netshort-grab for id={film_id}, limit={limit}")
    req_json = json.dumps({"id": film_id, "limit": limit})
    node_exe = None
    for cand in [
        os.path.join(BASE_DIR, "patchright", "driver", "node.exe"),
        os.path.join(BASE_DIR, "playwright", "driver", "node.exe"),
        r"C:\Program Files\nodejs\node.exe",
    ]:
        if os.path.exists(cand):
            node_exe = cand
            break
    if not node_exe:
        node_exe = shutil.which("node") or "node"
    try:
        proc = subprocess.run(
            [node_exe, helper_script],
            input=req_json,
            text=True,
            capture_output=True,
            encoding="utf-8",
            timeout=45,
            creationflags=0x08000000 if sys.platform == "win32" else 0
        )
        if proc.returncode == 0 and proc.stdout.strip():
            data = json.loads(proc.stdout.strip())
            ep_cnt = len(data.get("episodes", []))
            film_title = data.get("film", {}).get("title", "")
            log(f"Netshort grab success: {ep_cnt} episodes returned for {film_id} ({film_title})")
            return data
        else:
            log(f"Netshort helper error: code {proc.returncode}, stderr: {proc.stderr[:300]}")
    except Exception as e:
        log(f"call_netshort_grab exception: {e}")

    # Fallback to drama_downloader NetShortPlatform
    try:
        log(f"Falling back to drama_downloader NetShort for {film_id}")
        return call_drama_action("drama-grab", {"url": f"netshort:{film_id}", "limit": limit})
    except Exception as e:
        log(f"NetShort drama_downloader fallback error: {e}")
        return {"ok": False, "message": str(e)}

def call_drama_action(action, params):
    raw_url = str(params.get("url") or params.get("id") or params.get("series_id") or "").strip()
    if not raw_url:
        return {"ok": False, "message": "Missing URL or series_id"}

    limit = int(params.get("limit") or 0)
    platform_hint = str(params.get("platform") or params.get("platform_hint") or "").strip() or None

    log(f"Handling drama-grab for {raw_url} (limit={limit}, hint={platform_hint})")
    try:
        from concurrent.futures import ThreadPoolExecutor
        import drama_downloader.platforms as ddp

        series = ddp.load_series(raw_url, platform_hint=platform_hint)
        if not series or not series.episodes:
            return {"ok": False, "message": f"No episodes returned for {raw_url}"}

        target_eps = series.episodes[:limit] if (limit > 0) else series.episodes

        # Concurrent resolution of direct stream URLs (unlocks locked episodes in parallel)
        eps_needing_url = [ep for ep in target_eps if not ep.direct_url]
        if eps_needing_url:
            log(f"Resolving stream URLs for {len(eps_needing_url)} episodes concurrently...")
            def _resolve_ep(ep):
                try:
                    v = ddp.get_video_url(ep, platform_hint=series.platform)
                    if v:
                        ep.direct_url = v
                        ep.locked = False
                except Exception as ex:
                    log(f"Error resolving ep {ep.num}: {ex}")
                return ep

            worker_count = min(12, max(2, len(eps_needing_url)))
            with ThreadPoolExecutor(max_workers=worker_count) as pool:
                list(pool.map(_resolve_ep, eps_needing_url))

        episodes_data = []
        for ep in target_eps:
            v_url = ep.direct_url
            if not v_url or not str(v_url).startswith("http"):
                enc_u = urllib.parse.quote(ep.url or raw_url)
                v_url = f"http://127.0.0.1:8765/api/mock/drama-stream?platform={series.platform}&ep={ep.num}&url={enc_u}"

            subs_list = [s.to_dict() for s in ep.subs] if ep.subs else []
            ep_dict = {
                "index": ep.num,
                "episode_no": ep.num,
                "title": ep.title,
                "item_id": f"{series.platform}_{ep.num}",
                "cover": ep.thumb or series.cover or "",
                "cover_url": ep.thumb or series.cover or "",
                "url": v_url,
                "play_urls": [v_url],
                "duration": 0,
                "duration_s": 0,
                "locked": False,
                "subs": subs_list,
                "extra": {
                    "platform": series.platform,
                    "subs": subs_list,
                    **(ep.extra or {})
                }
            }
            episodes_data.append(ep_dict)

        film_data = {
            "title": series.name,
            "cover": series.cover or "",
            "desc": series.description or "",
            "total": series.episode_count or len(series.episodes),
            "platform": series.platform
        }
        accessible = len(episodes_data)
        log(f"Drama grab success: {len(episodes_data)} episodes unlocked for {series.name} ({series.platform})")
        return {
            "ok": True,
            "film": film_data,
            "series": film_data,
            "episodes": episodes_data,
            "total": len(episodes_data),
            "accessible": accessible
        }
    except Exception as e:
        log(f"call_drama_action error for {raw_url}: {e}")
        return {"ok": False, "message": str(e)}

_douyin_cache = {}

def call_douyin_resolve(params):
    raw_url = str(params.get("url") or params.get("id") or "")
    if not raw_url:
        return {"ok": False, "message": "Missing Douyin URL or ID"}

    import re
    vid_m = re.search(r"(?:video|note)/(\d+)", raw_url) or re.search(r"[?&]modal_id=(\d+)", raw_url) or re.search(r"[?&]vid=(\d+)", raw_url) or re.search(r"(\d{15,25})", raw_url)
    if not vid_m:
        return {"ok": False, "message": "Invalid Douyin video URL"}
    aid = vid_m.group(1)

    now = time.time()
    if aid in _douyin_cache:
        cached = _douyin_cache[aid]
        if now - cached.get("ts", 0) < 3600:
            log(f"Douyin resolve hit cache for {aid}: {cached.get('title', '')[:30]}")
            return {"ok": True, "play_url": cached["play_url"], "title": cached.get("title", ""), "cached": True}

    profile_dir = None
    try:
        import bili_patch
        profile_dir = bili_patch.get_douyin_profile_dir()
    except Exception:
        pass
    if not profile_dir:
        for cand in [
            os.path.join(os.environ.get("APPDATA", ""), "XuongDowloader", "douyin_profile"),
            os.path.join(os.environ.get("APPDATA", ""), "ReupStudio", "douyin_profile"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "XuongDowloader", "browser_pw", "default"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "ReupStudio", "browser_pw", "default"),
        ]:
            if os.path.isdir(cand):
                profile_dir = cand
                break

    chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    if not os.path.exists(chrome_path):
        chrome_path = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

    try:
        from patchright.sync_api import sync_playwright
        aweme_box = []
        with sync_playwright() as p:
            if profile_dir and os.path.isdir(profile_dir):
                ctx = p.chromium.launch_persistent_context(
                    profile_dir,
                    executable_path=chrome_path,
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled", "--no-sandbox"]
                )
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
            else:
                browser = p.chromium.launch(
                    executable_path=chrome_path,
                    headless=True,
                    args=["--disable-blink-features=AutomationControlled", "--no-sandbox"]
                )
                page = browser.new_page(
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                    viewport={"width": 1280, "height": 800}
                )
                ctx = browser

            def on_resp(r):
                if ("detail" in r.url or "aweme" in r.url) and r.status == 200:
                    try:
                        b = r.body()
                        if b:
                            data = json.loads(b.decode("utf-8", "ignore"))
                            if isinstance(data, dict) and data.get("aweme_detail"):
                                aweme_box.append(data["aweme_detail"])
                    except Exception:
                        pass
            page.on("response", on_resp)
            page.goto(f"https://www.douyin.com/video/{aid}", wait_until="domcontentloaded", timeout=15000)
            for _ in range(12):
                if aweme_box:
                    break
                page.wait_for_timeout(400)
            ctx.close()

        if aweme_box:
            item = aweme_box[0]
            title = item.get("desc", f"Douyin {aid}")
            vid_obj = item.get("video", {})
            urls = vid_obj.get("play_addr", {}).get("url_list", [])
            if urls:
                best_url = urls[0]
                for u in urls:
                    if "zjcdn.com" in u:
                        best_url = u
                        break
                _douyin_cache[aid] = {"play_url": best_url, "title": title, "ts": now}
                log(f"Douyin resolve success for {aid}: {title[:40]} -> {best_url[:60]}")
                return {"ok": True, "play_url": best_url, "title": title}
    except Exception as ex:
        log(f"call_douyin_resolve error: {ex}")

    return {"ok": False, "message": "Douyin resolution failed"}

_bili_cache = {}

def call_bilibili_resolve(params):
    import re
    raw_url = params.get("url", "").strip() if isinstance(params, dict) else str(params).strip()
    if not raw_url:
        return {"ok": False, "message": "No Bilibili URL provided"}

    now = time.time()
    if raw_url in _bili_cache and (now - _bili_cache[raw_url].get("ts", 0)) < 1800:
        c = _bili_cache[raw_url]
        return {"ok": True, "play_url": c["video_url"], "video_url": c["video_url"], "audio_url": c.get("audio_url", ""), "title": c.get("title", "")}

    # Bilibili TV: /play/{season_id}/{ep_id} or /video/{aid}
    ep_m = re.search(r"/play/\d+/(\d+)", raw_url) or re.search(r"[?&]episode_id=(\d+)", raw_url) or re.search(r"/video/(\d+)", raw_url)
    if ep_m and ("bilibili.tv" in raw_url or "biliintl.com" in raw_url or "bstar" in raw_url):
        ep_id = ep_m.group(1)
        log(f"Resolving Bilibili International ep_id={ep_id} via signed mobile API...")
        try:
            import hashlib
            appkey = "7d089525d3611b1c"
            appsec = "acd495b248ec528c2eed1e862d393126"
            api_params = {
                "ep_id": ep_id,
                "mobi_app": "bstar_a",
                "platform": "android",
                "device": "android",
                "build": "1001310",
                "s_locale": "vi_VN",
                "fnval": "0",
                "qn": "64",
                "appkey": appkey,
                "ts": int(time.time()),
            }
            sorted_items = sorted(api_params.items())
            qs = urllib.parse.urlencode(sorted_items)
            sign = hashlib.md5((qs + appsec).encode("utf-8")).hexdigest()
            api_params["sign"] = sign
            signed_qs = urllib.parse.urlencode(api_params)

            api_url = f"https://api.bilibili.tv/intl/gateway/v2/ogv/playurl?{signed_qs}"
            req = urllib.request.Request(api_url, headers={
                "User-Agent": "Bilibili/1.39.0 (Android)",
                "Referer": "https://www.bilibili.tv/"
            })
            with urllib.request.urlopen(req, timeout=12) as r:
                res_data = json.loads(r.read().decode("utf-8", "ignore"))

            v_info = res_data.get("data", {}).get("video_info", {})
            stream_list = v_info.get("stream_list", [])
            dash_audio = v_info.get("dash_audio", [])

            best_video_url = ""
            for s in stream_list:
                dash_v = s.get("dash_video", {})
                u = dash_v.get("base_url") or (dash_v.get("backup_url", [""])[0] if dash_v.get("backup_url") else "")
                if u and u.startswith("http"):
                    best_video_url = u
                    break

            best_audio_url = ""
            if dash_audio:
                for a in sorted(dash_audio, key=lambda x: x.get("bandwidth", 0), reverse=True):
                    u = a.get("base_url") or (a.get("backup_url", [""])[0] if a.get("backup_url") else "")
                    if u and u.startswith("http"):
                        best_audio_url = u
                        break

            if best_video_url:
                title = f"Bilibili_TV_{ep_id}"
                _bili_cache[raw_url] = {"video_url": best_video_url, "audio_url": best_audio_url, "title": title, "ts": now}
                log(f"Bilibili TV resolve success for {ep_id}: video={best_video_url[:60]}")
                return {"ok": True, "play_url": best_video_url, "video_url": best_video_url, "audio_url": best_audio_url, "title": title}
        except Exception as e:
            log(f"Bilibili TV resolve error for {ep_id}: {e}")

    return {"ok": False, "message": "Bilibili resolution failed"}

def handle_mock_request(path, body):
    log(f"Dispatching mock request: path={path}")

    # Bilibili Stream Resolver
    if "/api/bilibili/resolve" in path:
        params = body.get("params") if isinstance(body.get("params"), dict) else body
        if "?" in path:
            qs = path.split("?", 1)[1]
            for pair in qs.split("&"):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    if k not in params:
                        params[k] = urllib.parse.unquote(v)
        return call_bilibili_resolve(params)

    # Douyin Stream Resolver
    if "/api/douyin/resolve" in path:
        params = body.get("params") if isinstance(body.get("params"), dict) else body
        if "?" in path:
            qs = path.split("?", 1)[1]
            for pair in qs.split("&"):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    if k not in params:
                        params[k] = urllib.parse.unquote(v)
        return call_douyin_resolve(params)

    # Universal Drama Grabber (DramaBox, GoodShort, ShortMax, NetShort, FreeReels, KissKH, Hongguo, etc.)
    if "/api/drama/grab" in path or "/api/mock/drama-grab" in path or "/api/mock/drama" in path:
        params = body.get("params") if isinstance(body.get("params"), dict) else body
        if "?" in path:
            qs = path.split("?", 1)[1]
            for pair in qs.split("&"):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    if k not in params:
                        params[k] = urllib.parse.unquote(v)
        return call_drama_action("drama-grab", params)

    # On-demand Drama Stream Resolver
    if "/api/mock/drama-stream" in path or "/api/drama/stream" in path:
        params = body.get("params") if isinstance(body.get("params"), dict) else body
        if "?" in path:
            qs = path.split("?", 1)[1]
            for pair in qs.split("&"):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    if k not in params:
                        params[k] = urllib.parse.unquote(v)
        platform_name = str(params.get("platform") or "").strip()
        ep_num = int(params.get("ep") or params.get("episode") or 1)
        target_url = str(params.get("url") or "").strip()
        try:
            import drama_downloader.platforms as ddp
            series = ddp.load_series(target_url, platform_hint=platform_name or None)
            target_ep = next((e for e in series.episodes if e.num == ep_num), None)
            if target_ep:
                v_url = target_ep.direct_url or ddp.get_video_url(target_ep, platform_hint=series.platform)
                if v_url:
                    log(f"drama-stream on-demand resolved: EP{ep_num} -> {v_url[:50]}")
                    return {"ok": True, "stream_url": v_url, "url": v_url}
        except Exception as e:
            log(f"drama-stream resolution error: {e}")
        return {"ok": False, "message": "Stream resolution failed"}

    # License API for QML / UI Activation
    if "/api/license/status" in path:
        return license_manager.get_license_status()

    if "/api/license/activate" in path:
        key = body.get("key", "")
        return license_manager.activate_with_key(key)

    if "/api/license/sync_sheet" in path:
        key = body.get("key", "")
        if not key or "đang" in str(key).lower() or len(str(key)) < 15:
            key = license_manager.get_machine_code()
        return license_manager.sync_with_google_sheet(entered_key=key)

    if "/api/license/register" in path:
        name = body.get("name", "")
        key = body.get("key", "")
        if not key or "đang" in str(key).lower() or len(str(key)) < 15:
            key = license_manager.get_machine_code()
        return license_manager.register_customer(customer_name=name, machine_code=key)

    if "/tool-license" in path:
        lic = license_manager.get_license_status()
        if lic.get("is_activated"):
            return {
                "ok": True,
                "valid": True,
                "vip": True,
                "reup": True,
                "explore": True,
                "lifetime": True,
                "role": "vip",
                "expiry": lic.get("expiry") or "2099-12-31",
                "token": "vip_lifetime_unlimited",
                "username": lic.get("customer_name") or "VIP_Pro_User",
                "message": lic.get("message") or "Bản quyền VIP vĩnh viễn"
            }
        else:
            return {
                "ok": False,
                "valid": False,
                "vip": False,
                "reup": False,
                "explore": False,
                "message": lic.get("message") or "Chưa kích hoạt bản quyền"
            }
    if "/api/mock/ota-update" in path or "/api/ota/update" in path:
        log("[OTA] Nhan duoc yeu cau cap nhat tu xa!")
        bat_file = os.path.join(BASE_DIR, "Cap_Nhat_Tu_Xa.bat")
        updater_py = os.path.join(BASE_DIR, "ota_updater.py")

        # Tim python executable
        py_exe = sys.executable
        for candidate in [
            os.path.join(BASE_DIR, "engine", "python", "python.exe"),
            os.path.join(BASE_DIR, "python.exe"),
            os.path.join(BASE_DIR, "reup_engine.exe"),
            sys.executable,
        ]:
            if candidate and os.path.exists(candidate):
                py_exe = candidate
                break

        # Neu khong co bat_file trong BASE_DIR, tao script bat tam thoi trong TEMP
        if not os.path.exists(bat_file):
            temp_bat = os.path.join(os.environ.get("TEMP", "C:\\Windows\\Temp"), "Cap_Nhat_XuongDowloader.bat")
            try:
                with open(temp_bat, "w", encoding="utf-8") as f:
                    f.write(f'@echo off\ncd /d "{BASE_DIR}"\n"{py_exe}" "{updater_py}"\npause\n')
                bat_file = temp_bat
            except Exception as e:
                log(f"[OTA] Khong the tao temp bat: {e}")

        launched = False
        try:
            ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", py_exe, f'"{updater_py}"', BASE_DIR, 1)
            if ret > 32:
                launched = True
        except Exception as e:
            log(f"[OTA] ShellExecute python err: {e}")

        if not launched and os.path.exists(bat_file):
            try:
                ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", bat_file, None, BASE_DIR, 1)
                if ret > 32:
                    launched = True
            except Exception as e:
                log(f"[OTA] ShellExecute bat err: {e}")

        if not launched:
            try:
                ps_script = f"Start-Process '{py_exe}' -ArgumentList '\"{updater_py}\"' -Verb RunAs"
                subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script], cwd=BASE_DIR)
                launched = True
            except Exception as e:
                log(f"[OTA] PowerShell RunAs err: {e}")

        return {"ok": launched, "message": "Đang mở trình Cập Nhật Từ Xa Một Chạm..." if launched else "Không thể khởi chạy cập nhật"}

    if "/api/mock/ota-check" in path or "/api/ota/check" in path:
        cfg_path = os.path.join(BASE_DIR, "update_config.json")
        cfg = {}
        if os.path.exists(cfg_path):
            try:
                with open(cfg_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
            except Exception:
                pass
        return {
            "ok": True,
            "version": cfg.get("version", "1.1.2"),
            "channel": cfg.get("channel", "stable"),
            "update_source": cfg.get("update_source", "gdrive")
        }

    pure_path = path.split("?")[0]
    action = body.get("action", "")
    if not action and "/" in pure_path:
        action = pure_path.rstrip("/").split("/")[-1]

    params = body.get("params")
    if not isinstance(params, dict) or not params:
        params = dict(body)

    if "?" in path:
        qs = path.split("?", 1)[1]
        for pair in qs.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                if k not in params:
                    params[k] = urllib.parse.unquote(v)

    log(f"Action: {action}, series_id={params.get('series_id')}, id={params.get('id')}")

    # Enforce license for scraping actions
    lic = license_manager.get_license_status()
    if not lic.get("is_activated") and not lic.get("is_vip_build"):
        return {"ok": False, "message": "Chưa kích hoạt bản quyền phần mềm! Vui lòng liên hệ Admin qua Telegram @ytbgoogle."}

    if action in ("hongguo-grab", "hongguo-search", "hongguo-feed", "hongguo-detail"):
        res = call_hongguo_action(action, params)
        if (not res or not res.get("ok")) and action == "hongguo-grab":
            log("Hongguo native grab failed, trying drama_downloader...")
            hg_res = call_drama_action("drama-grab", params)
            if hg_res.get("ok"):
                return hg_res
        return res

    if action == "netshort-grab":
        res = call_netshort_grab(params)
        if not res or not res.get("ok") or not res.get("episodes"):
            log("NetShort native grab failed, trying drama_downloader...")
            ns_id = params.get("id") or params.get("series_id") or ""
            ns_res = call_drama_action("drama-grab", {"url": f"netshort:{ns_id}", **params})
            if ns_res.get("ok"):
                return ns_res
        return res

    if action in (
        "drama-grab", "shortdrama-grab", "dramabox-grab", "goodshort-grab",
        "shortmax-grab", "freereels-grab", "kisskh-grab", "dramawave-grab",
        "raptdrama-grab", "flextv-grab", "stardusttv-grab"
    ):
        return call_drama_action(action, params)

    return {"ok": True, "message": "success", "data": []}

# 4. SSL Context for rpa.momigo.ai
server_cert = os.path.join(CERT_DIR, "server.crt")
server_key = os.path.join(CERT_DIR, "server.key")
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(certfile=server_cert, keyfile=server_key)

def handle_bilibili_tls_request(method, path, headers_lines, body_bytes):
    log(f"Bilibili TLS intercept: {method} {path[:90]}")
    # 1. Mock nav -> Always report VIP login
    if "/x/web-interface/nav" in path:
        log("Returning mock Bilibili VIP status")
        mock_data = {
            "code": 0,
            "message": "0",
            "ttl": 1,
            "data": {
                "isLogin": True,
                "email_verified": 1,
                "face": "https://static.hdslb.com/images/member/noface.gif",
                "level_info": {"current_level": 6},
                "mid": 25329626,
                "mobile_verified": 1,
                "money": 1000,
                "moral": 70,
                "scores": 0,
                "uname": "VIP_Pro_User",
                "vipDueDate": 1999999999,
                "vipStatus": 1,
                "vipType": 2
            }
        }
        payload = json.dumps(mock_data, ensure_ascii=False).encode("utf-8")
        headers = (
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: application/json; charset=utf-8\r\n"
            b"Content-Length: " + str(len(payload)).encode("ascii") + b"\r\n"
            b"Access-Control-Allow-Origin: *\r\n"
            b"Connection: close\r\n"
            b"\r\n"
        )
        return headers, payload

    # 2. Intercept arc/search or arc/list (bypasses 412 via mobile API and auto-aggregates full channel)
    if "/arc/search" in path or "/arc/list" in path:
        query = urllib.parse.urlsplit(path).query
        qs = urllib.parse.parse_qs(query)
        mid = qs.get("mid", [""])[0]
        if not mid:
            for h in headers_lines:
                if h.lower().startswith("referer:"):
                    m = re.search(r'space\.bilibili\.com/(\d+)', h)
                    if m:
                        mid = m.group(1)
                        break

        pn = int(qs.get("pn", ["1"])[0])
        order = qs.get("order", ["pubdate"])[0]
        if order not in ("pubdate", "click", "stow"):
            order = "pubdate"

        log(f"Handling arc/search for mid={mid}, pn={pn}, order={order}")

        # Fetch channel videos using anonymous mobile API (up to 500 videos / 10 pages)
        all_vlist = []
        total_channel = 0
        cur_pn = 1
        max_pages = 10
        headers_dict = {
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "Referer": f"https://m.bilibili.com/space/{mid}",
            "Accept": "application/json, text/plain, */*"
        }

        while cur_pn <= max_pages:
            mobile_url = f"https://api.bilibili.com/x/space/arc/search?mid={mid}&ps=50&tid=0&pn={cur_pn}&order={order}"
            try:
                req = urllib.request.Request(mobile_url, headers=headers_dict)
                with urllib.request.urlopen(req, timeout=12) as resp:
                    page_data = json.loads(resp.read().decode("utf-8"))
                    if page_data.get("code") != 0:
                        break
                    items = page_data.get("data", {}).get("list", {}).get("vlist", [])
                    total_channel = page_data.get("data", {}).get("page", {}).get("count", 0)
                    if not items:
                        break
                    all_vlist.extend(items)
                    if len(all_vlist) >= total_channel or len(items) < 50:
                        break
                    cur_pn += 1
            except Exception as e:
                log(f"Mobile fetch page {cur_pn} error: {e}")
                break

        log(f"Total channel videos fetched for mid={mid}: {len(all_vlist)}/{total_channel}")

        mock_resp = {
            "code": 0,
            "message": "0",
            "ttl": 1,
            "data": {
                "list": {
                    "vlist": all_vlist
                },
                "page": {
                    "count": total_channel or len(all_vlist),
                    "pn": pn,
                    "ps": len(all_vlist)
                }
            }
        }
        payload = json.dumps(mock_resp, ensure_ascii=False).encode("utf-8")
        headers = (
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: application/json; charset=utf-8\r\n"
            b"Content-Length: " + str(len(payload)).encode("ascii") + b"\r\n"
            b"Access-Control-Allow-Origin: *\r\n"
            b"Connection: close\r\n"
            b"\r\n"
        )
        return headers, payload

    # 3. Transparent forward for all other requests to api.bilibili.com
    try:
        fwd_url = "https://api.bilibili.com" + path
        fwd_headers = {}
        for h in headers_lines[1:]:
            if ":" in h:
                k, v = h.split(":", 1)
                k_clean = k.strip().lower()
                if k_clean not in ("host", "content-length"):
                    fwd_headers[k.strip()] = v.strip()
        fwd_req = urllib.request.Request(fwd_url, data=body_bytes if body_bytes else None, headers=fwd_headers, method=method)
        with urllib.request.urlopen(fwd_req, timeout=15) as fwd_resp:
            payload = fwd_resp.read()
            status = fwd_resp.status
            content_type = fwd_resp.headers.get("Content-Type", "application/json")
            headers = (
                f"HTTP/1.1 {status} OK\r\n"
                f"Content-Type: {content_type}\r\n"
                f"Content-Length: {len(payload)}\r\n"
                f"Access-Control-Allow-Origin: *\r\n"
                f"Connection: close\r\n"
                f"\r\n"
            ).encode("latin1")
            return headers, payload
    except urllib.error.HTTPError as he:
        payload = he.read()
        headers = (
            f"HTTP/1.1 {he.code} Error\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(payload)}\r\n"
            f"Connection: close\r\n"
            f"\r\n"
        ).encode("latin1")
        return headers, payload
    except Exception as e:
        log(f"Bilibili forward exception: {e}")
        err_payload = b'{"code":-502,"message":"Gateway Error"}'
        headers = (
            b"HTTP/1.1 502 Bad Gateway\r\n"
            b"Content-Type: application/json\r\n"
            b"Content-Length: " + str(len(err_payload)).encode("ascii") + b"\r\n"
            b"Connection: close\r\n"
            b"\r\n"
        )
        return headers, err_payload

def handle_tls_client(tls_sock, host=""):
    """Handles decrypted HTTPS traffic inside the CONNECT tunnel."""
    try:
        tls_sock.settimeout(300.0)
        req_data = b""
        while b"\r\n\r\n" not in req_data:
            chunk = tls_sock.recv(4096)
            if not chunk:
                return
            req_data += chunk

        header_bytes, rest = req_data.split(b"\r\n\r\n", 1)
        headers_lines = header_bytes.decode("latin1").split("\r\n")
        req_line = headers_lines[0]
        method, path, _ = req_line.split(" ", 2)

        content_length = 0
        for h in headers_lines[1:]:
            if ":" in h:
                k, v = h.split(":", 1)
                if k.strip().lower() == "content-length":
                    content_length = int(v.strip())

        body_bytes = rest
        while len(body_bytes) < content_length:
            chunk = tls_sock.recv(4096)
            if not chunk:
                break
            body_bytes += chunk

        if "raw.githubusercontent.com" in host:
            config_payload = json.dumps({
                "license_url": "https://rpa.momigo.ai/webhook/tool-license",
                "reup_api_url": "https://rpa.momigo.ai/webhook/reup",
                "latest_version": "1.1.1",
                "download_url": "https://github.com/nguyendinhlam88/reup/releases/download/v0.1.23/MediaStudio-Setup.exe",
                "sig": "yVWNFbnY5VGxMdaOZBnzjukx5tKpUrXZWeaSIks/hJdVr9hwYqsrHg22cZ/f7Dxd7/oUSLRonuhDgbhIYjBLCg=="
            }, ensure_ascii=False).encode("utf-8")
            resp_headers = (
                b"HTTP/1.1 200 OK\r\n"
                b"Content-Type: application/json; charset=utf-8\r\n"
                b"Content-Length: " + str(len(config_payload)).encode("ascii") + b"\r\n"
                b"Access-Control-Allow-Origin: *\r\n"
                b"Connection: close\r\n"
                b"\r\n"
            )
            tls_sock.sendall(resp_headers + config_payload)
            return

        if "bilibili.com" in host:
            resp_headers, resp_payload = handle_bilibili_tls_request(method, path, headers_lines, body_bytes)
            tls_sock.sendall(resp_headers + resp_payload)
            return

        body_json = {}
        if body_bytes:
            try:
                body_json = json.loads(body_bytes.decode("utf-8"))
            except Exception:
                pass

        resp_obj = handle_mock_request(path, body_json)
        resp_payload = json.dumps(resp_obj, ensure_ascii=False).encode("utf-8")

        resp_headers = (
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: application/json; charset=utf-8\r\n"
            b"Content-Length: " + str(len(resp_payload)).encode("ascii") + b"\r\n"
            b"Connection: close\r\n"
            b"\r\n"
        )
        tls_sock.sendall(resp_headers + resp_payload)
    except Exception as e:
        log(f"TLS handler error: {e}")
    finally:
        try:
            tls_sock.close()
        except Exception:
            pass

def bridge_sockets(sock1, sock2, initial_data=b""):
    """Bidirectional socket forwarding using dedicated high-throughput pump threads."""
    try:
        sock1.setblocking(True)
        sock2.setblocking(True)
    except Exception:
        pass

    if initial_data:
        try:
            sock2.sendall(initial_data)
        except Exception:
            pass

    def pump(src, dst):
        try:
            while True:
                data = src.recv(32768)
                if not data:
                    break
                dst.sendall(data)
        except Exception:
            pass
        finally:
            try: dst.shutdown(socket.SHUT_WR)
            except Exception: pass
            try: src.close()
            except Exception: pass
            try: dst.close()
            except Exception: pass

    threading.Thread(target=pump, args=(sock1, sock2), daemon=True).start()
    threading.Thread(target=pump, args=(sock2, sock1), daemon=True).start()

def handle_proxy_conn(client_sock):
    """Processes incoming proxy requests (CONNECT or standard HTTP)."""
    try:
        client_sock.settimeout(60.0)
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = client_sock.recv(4096)
            if not chunk:
                break
            buf += chunk

        if not buf:
            client_sock.close()
            return

        head, rest = buf.split(b"\r\n\r\n", 1)
        headers_lines = head.decode("latin1").split("\r\n")
        req_line = headers_lines[0].strip()
        parts = req_line.split(" ")
        if len(parts) < 2:
            client_sock.close()
            return

        method, target = parts[0], parts[1]
        headers_data = b"\r\n".join([line.encode("latin1") for line in headers_lines[1:]]) + b"\r\n\r\n"

        if method.upper() == "CONNECT":
            # CONNECT target:port
            host, port_str = target.split(":", 1) if ":" in target else (target, "443")
            port = int(port_str)

            if "momigo.ai" in host or "raw.githubusercontent.com" in host:
                # Intercept!
                client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                tls_sock = ssl_context.wrap_socket(client_sock, server_side=True)
                threading.Thread(target=handle_tls_client, args=(tls_sock, host), daemon=True).start()
            else:
                # Passthrough directly to external server
                try:
                    remote_sock = socket.create_connection((host, port), timeout=15.0)
                    client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                    bridge_sockets(client_sock, remote_sock, rest)
                except Exception as e:
                    log(f"Tunnel connect fail to {host}:{port}: {e}")
                    client_sock.sendall(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
                    client_sock.close()
        else:
            # Standard plain HTTP request (e.g. GET http://host:port/path HTTP/1.1 or POST /api/mock)
            url_parts = urllib.parse.urlsplit(target)
            host = url_parts.hostname or "127.0.0.1"
            port = url_parts.port or 80
            path = url_parts.path or "/"
            if url_parts.query:
                path += "?" + url_parts.query

            if method.upper() == "OPTIONS" and path.startswith(("/webhook", "/api")):
                cors_resp = (
                    b"HTTP/1.1 204 No Content\r\n"
                    b"Access-Control-Allow-Origin: *\r\n"
                    b"Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                    b"Access-Control-Allow-Headers: *\r\n"
                    b"Connection: close\r\n\r\n"
                )
                client_sock.sendall(cors_resp)
                client_sock.close()
                return

            # Check if this plain HTTP request is destined for local mock
            if "momigo.ai" in host or path.startswith(("/webhook", "/api")):
                content_length = 0
                for h in headers_data.decode("latin1").split("\r\n"):
                    if ":" in h:
                        k, v = h.split(":", 1)
                        if k.strip().lower() == "content-length":
                            content_length = int(v.strip())
                body_bytes = rest
                while len(body_bytes) < content_length:
                    chunk = client_sock.recv(4096)
                    if not chunk:
                        break
                    body_bytes += chunk
                body_json = {}
                if body_bytes:
                    try:
                        body_json = json.loads(body_bytes.decode("utf-8"))
                    except Exception as e:
                        log(f"JSON parse error: {e}, raw: {body_bytes}")
                log(f"Mock request {method} {path}, json={body_json}")
                resp_obj = handle_mock_request(path, body_json)
                if path.startswith("/api/mock/drama-stream") and resp_obj.get("stream_url"):
                    stream_loc = resp_obj["stream_url"].encode("utf-8")
                    redir_resp = (
                        b"HTTP/1.1 302 Found\r\n"
                        b"Location: " + stream_loc + b"\r\n"
                        b"Access-Control-Allow-Origin: *\r\n"
                        b"Connection: close\r\n\r\n"
                    )
                    client_sock.sendall(redir_resp)
                    client_sock.close()
                    return
                resp_payload = json.dumps(resp_obj, ensure_ascii=False).encode("utf-8")
                resp_headers = (
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: application/json; charset=utf-8\r\n"
                    b"Access-Control-Allow-Origin: *\r\n"
                    b"Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                    b"Access-Control-Allow-Headers: *\r\n"
                    b"Content-Length: " + str(len(resp_payload)).encode("ascii") + b"\r\n"
                    b"Connection: close\r\n"
                    b"\r\n"
                )
                client_sock.sendall(resp_headers + resp_payload)
                client_sock.close()
                return

            try:
                remote_sock = socket.create_connection((host, port), timeout=30.0)
                req_init = f"{method} {path} HTTP/1.1\r\n".encode("latin1")
                remote_sock.sendall(req_init + headers_data)
                threading.Thread(target=bridge_sockets, args=(client_sock, remote_sock), daemon=True).start()
            except Exception as e:
                log(f"Plain HTTP proxy error to {target}: {e}")
                client_sock.sendall(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
                client_sock.close()
    except Exception as e:
        log(f"Proxy client error: {e}")
        try: client_sock.close()
        except Exception: pass

def run_proxy_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", PROXY_PORT))
    server.listen(128)
    log(f"ReupStudio Local Bridge listening on 127.0.0.1:{PROXY_PORT}")
    while True:
        client, addr = server.accept()
        threading.Thread(target=handle_proxy_conn, args=(client,), daemon=True).start()

def main():
    threading.Thread(target=ensure_signer, daemon=True).start()
    run_proxy_server()

if __name__ == "__main__":
    main()
