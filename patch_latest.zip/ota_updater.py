# -*- coding: utf-8 -*-
"""
ReupStudio / Xuong Dowloader - One-Touch Remote OTA Updater (Cập Nhật Từ Xa Một Chạm)
-------------------------------------------------------------------------------------
- Tự động phát hiện thư mục cài đặt (C:\\Program Files (x86)\\Xuong Dowloader [VIP] hoặc Portable)
- Tự động xin quyền Administrator (UAC elevation) nếu cài đặt trong Program Files
- Tải bản vá siêu nhẹ (patch_latest.zip ~200KB) từ Google Drive hoặc link máy chủ / GitHub
- Tự động đóng ứng dụng đang chạy để tránh khóa file, sao lưu bản cũ
- Giải nén bản vá, xóa triệt để cache __pycache__ và file .pyc cũ
- Khởi động lại ứng dụng và hiển thị thông báo thành công
"""

import os
import sys
import re
import time
import json
import shutil
import zipfile
import urllib.request
import urllib.parse
import urllib.error
import subprocess
import ctypes

APP_TITLE = "Xưởng Dowloader - Cập Nhật Từ Xa"
CURRENT_VERSION = "1.1.2"
CONFIG_FILE_NAME = "update_config.json"

DEFAULT_CONFIG = {
    "version": CURRENT_VERSION,
    "channel": "stable",
    "update_source": "gdrive",
    # Mặc định Google Drive ID hoặc direct download URL
    # Bạn chỉ cần thay đổi gdrive_file_id hoặc direct_url trong file update_config.json
    "gdrive_file_id": "1A2B3C4D5E_placeholder",
    "direct_url": "https://raw.githubusercontent.com/reupstudio/updates/main/patch_latest.zip",
    "manifest_url": "https://raw.githubusercontent.com/reupstudio/updates/main/version.json",
    "app_exe": "XuongDowloader.exe"
}

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

def run_as_admin():
    if is_admin():
        return True
    args = " ".join([f'"{a}"' for a in sys.argv])
    try:
        ret = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, args, None, 1
        )
        if ret > 32:
            sys.exit(0)
    except Exception as e:
        print(f"Loi xin quyen Administrator: {e}")
    return False

def show_msg(title, message, icon_type=0x40):
    """
    icon_type: 0x40 = Info (MB_ICONINFORMATION), 0x30 = Warning, 0x10 = Error
    """
    try:
        ctypes.windll.user32.MessageBoxW(0, str(message), str(title), icon_type | 0x10000)
    except Exception:
        print(f"[{title}] {message}")

def ask_yes_no(title, message):
    try:
        res = ctypes.windll.user32.MessageBoxW(0, str(message), str(title), 0x04 | 0x20 | 0x10000)
        return res == 6  # IDYES = 6
    except Exception:
        return True

def detect_install_dir():
    # 1. Thu muc chua ota_updater.py
    self_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(os.path.join(self_dir, "bili_patch.py")) or os.path.exists(os.path.join(self_dir, "XuongDowloader.exe")):
        return self_dir

    # 2. Thu muc Program Files VIP
    p_vip = r"C:\Program Files (x86)\Xuong Dowloader VIP"
    if os.path.exists(p_vip):
        return p_vip

    # 3. Thu muc Program Files Standard
    p_std = r"C:\Program Files (x86)\Xuong Dowloader"
    if os.path.exists(p_std):
        return p_std

    # 4. Thu muc Workspace Dev
    p_dev = r"D:\ReupStudio\ReupStudio"
    if os.path.exists(p_dev):
        return p_dev

    return self_dir

def load_config(target_dir):
    cfg_path = os.path.join(target_dir, CONFIG_FILE_NAME)
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                cfg.update(data)
        except Exception:
            pass
    return cfg

def save_config(target_dir, cfg):
    cfg_path = os.path.join(target_dir, CONFIG_FILE_NAME)
    try:
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def extract_gdrive_id(url_or_id):
    if not url_or_id:
        return ""
    url_or_id = str(url_or_id).strip()
    # Match /file/d/<id>/
    m = re.search(r"/file/d/([a-zA-Z0-9_-]{25,})", url_or_id)
    if m:
        return m.group(1)
    # Match id=<id>
    m = re.search(r"[?&]id=([a-zA-Z0-9_-]{25,})", url_or_id)
    if m:
        return m.group(1)
    # Match direct ID string
    m = re.match(r"^[a-zA-Z0-9_-]{25,}$", url_or_id)
    if m:
        return m.group(0)
    return url_or_id

def download_from_google_drive(file_id_or_url, dest_path, progress_fn=None):
    file_id = extract_gdrive_id(file_id_or_url)
    if not file_id:
        raise ValueError("Invalid Google Drive file ID or URL")

    import http.cookiejar
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    opener.addheaders = [
        ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    ]

    base_url = f"https://drive.google.com/uc?export=download&id={file_id}"
    resp = opener.open(base_url, timeout=30)
    content = resp.read()

    # Check for confirmation token if large file
    confirm_token = None
    # 1. From cookies
    for cookie in cj:
        if cookie.name.startswith("download_warning"):
            confirm_token = cookie.value
            break
    # 2. From HTML response body
    if not confirm_token:
        text_body = content.decode("utf-8", errors="ignore")
        match = re.search(r'confirm=([0-9A-Za-z_-]+)', text_body)
        if match:
            confirm_token = match.group(1)
        elif "download_warning" in text_body:
            match = re.search(r'name="confirm"\s+value="([^"]+)"', text_body)
            if match:
                confirm_token = match.group(1)

    if confirm_token:
        download_url = f"https://drive.google.com/uc?export=download&confirm={confirm_token}&id={file_id}"
        resp = opener.open(download_url, timeout=60)
        total_sz = int(resp.headers.get("content-length", 0))
        downloaded = 0
        with open(dest_path, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if progress_fn and total_sz > 0:
                    progress_fn(downloaded, total_sz)
    else:
        # File is small enough and downloaded directly in initial read
        # Make sure it's actually binary zip, not an error HTML page
        if content.startswith(b"PK\x03\x04") or content.startswith(b"PK"):
            with open(dest_path, "wb") as f:
                f.write(content)
        else:
            # Let's try downloading via direct confirm=t
            download_url = f"https://drive.google.com/uc?export=download&confirm=t&id={file_id}"
            resp = opener.open(download_url, timeout=60)
            with open(dest_path, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)

    if not os.path.exists(dest_path) or os.path.getsize(dest_path) < 100:
        raise RuntimeError("Google Drive download returned an empty or invalid file")

    return True

def download_from_direct_url(url, dest_path, progress_fn=None):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "*/*"
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=60) as resp:
        total_sz = int(resp.headers.get("content-length", 0))
        downloaded = 0
        with open(dest_path, "wb") as f:
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if progress_fn and total_sz > 0:
                    progress_fn(downloaded, total_sz)
    return True

def kill_running_app():
    targets = ["XuongDowloader.exe", "ReupStudio_App.exe", "ReupStudio_VIP.exe", "reup_engine.exe"]
    for proc in targets:
        try:
            subprocess.run(["taskkill", "/F", "/IM", proc], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    time.sleep(1)

def apply_patch_zip(zip_path, target_dir):
    print(f"[*] Dang kiem tra file ban va: {os.path.basename(zip_path)}...")
    if not zipfile.is_zipfile(zip_path):
        raise RuntimeError("File ban va khong phai la file ZIP hop le!")

    # 1. Tao thu muc sao luu backup
    ts = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(target_dir, "backup_updates", f"backup_{ts}")
    os.makedirs(backup_dir, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as z:
        namelist = z.namelist()
        print(f"[*] Ban va co {len(namelist)} tap tin duoc cap nhat.")

        # Sao luu file cu neu ton tai
        for fname in namelist:
            if fname.endswith("/") or fname.endswith("\\"):
                continue
            dest_file = os.path.join(target_dir, fname)
            if os.path.exists(dest_file):
                b_dest = os.path.join(backup_dir, fname)
                os.makedirs(os.path.dirname(b_dest), exist_ok=True)
                try:
                    shutil.copyfile(dest_file, b_dest)
                except Exception:
                    pass

        # Giai nen de len file cu
        print("[*] Dang giai nen va ghi de file cap nhat...")
        z.extractall(target_dir)

    # 2. Xoa sach cache __pycache__ va file .pyc cu
    print("[*] Dang don dep cache cu de ma code moi hoat dong...")
    cleanup_extensions = [".pyc", ".pyo"]
    for root, dirs, files in os.walk(target_dir):
        if "__pycache__" in dirs:
            pyc_dir = os.path.join(root, "__pycache__")
            try:
                shutil.rmtree(pyc_dir, ignore_errors=True)
            except Exception:
                pass
        for f in files:
            if any(f.endswith(ext) for ext in cleanup_extensions):
                # Neu file pyc nay co file .py tuong ung thi xoa de python bien dich lai
                base_name = os.path.splitext(f)[0]
                py_equiv = os.path.join(root, base_name + ".py")
                if os.path.exists(py_equiv) and base_name not in ("unwrap_spade", "license_manager"):
                    try:
                        os.remove(os.path.join(root, f))
                    except Exception:
                        pass

    print("[+] Da giai nen ban va va lam sach cache thanh cong!")
    return True

def run_update_process(target_dir=None, patch_source=None, auto_restart=True, show_dialog=True):
    if not target_dir:
        target_dir = detect_install_dir()

    print("==================================================================")
    print("      XUONG DOWLOADER - HE THONG CAP NHAT TU XA MOT CHAM          ")
    print("==================================================================")
    print(f"[*] Thu muc cai dat: {target_dir}")

    # Kiem tra quyen ghi neu thu muc nam trong Program Files
    if "Program Files" in target_dir and not is_admin():
        print("[!] Phat hien can quyen Administrator. Dang yeu cau cap quyen...")
        run_as_admin()
        return

    cfg = load_config(target_dir)

    # Xac dinh nguon download
    source_url = patch_source or cfg.get("update_url") or cfg.get("gdrive_file_id") or cfg.get("direct_url")

    # Neu user nhap truc tiep link tu console
    if not patch_source and (not source_url or "placeholder" in source_url):
        print("\n[!] Chua cau hinh link ban cap nhat tu xa.")
        print("[?] Vui long nhap Link Google Drive (hoac link truc tiep) cua ban va:")
        user_in = input(">> Link cap nhat: ").strip()
        if user_in:
            source_url = user_in
            if "drive.google.com" in user_in:
                cfg["gdrive_file_id"] = user_in
                cfg["update_source"] = "gdrive"
            else:
                cfg["direct_url"] = user_in
                cfg["update_source"] = "direct"
            save_config(target_dir, cfg)
        else:
            print("[-] Da huy cap nhat.")
            return False

    temp_zip = os.path.join(os.environ.get("TEMP", target_dir), f"patch_update_{int(time.time())}.zip")

    print("\n[*] Dang ket noi va tai ban cap nhat tu xa...")
    try:
        def on_prog(down, total):
            pct = (down / total) * 100
            sys.stdout.write(f"\r[*] Dang tai: {pct:.1f}% ({down // 1024} KB / {total // 1024} KB)")
            sys.stdout.flush()

        if "drive.google.com" in source_url or cfg.get("update_source") == "gdrive" or extract_gdrive_id(source_url):
            print(f"[*] Nguon tai: Google Drive ({source_url})")
            download_from_google_drive(source_url, temp_zip, progress_fn=on_prog)
        else:
            print(f"[*] Nguon tai: Web Server ({source_url})")
            download_from_direct_url(source_url, temp_zip, progress_fn=on_prog)

        print("\n[+] Tai ban cap nhat ve may thanh cong!")
    except Exception as e:
        print(f"\n[-] Loi khi tai ban cap nhat: {e}")
        if show_dialog:
            show_msg(APP_TITLE, f"Không thể tải bản cập nhật:\n{e}\n\nVui lòng kiểm tra lại kết nối mạng hoặc link chia sẻ.", 0x10)
        return False

    # Dong ung dung dang chay
    print("[*] Dang tam dong Xuong Dowloader de cap nhat an toan...")
    kill_running_app()

    # Ap dung ban va
    try:
        apply_patch_zip(temp_zip, target_dir)
    except Exception as e:
        print(f"\n[-] Loi khi cai dat ban va: {e}")
        if show_dialog:
            show_msg(APP_TITLE, f"Lỗi khi cài đặt bản vá:\n{e}", 0x10)
        return False
    finally:
        try:
            if os.path.exists(temp_zip):
                os.remove(temp_zip)
        except Exception:
            pass

    # Cap nhat phien ban trong config
    cfg["version"] = CURRENT_VERSION
    save_config(target_dir, cfg)

    print("\n==================================================================")
    print(" [THÀNH CÔNG] DA CAP NHAT PHIEN BAN MOI THANH CONG!")
    print("==================================================================")

    # Hoi khoi dong lai app
    app_exe = os.path.join(target_dir, cfg.get("app_exe", "XuongDowloader.exe"))
    if not os.path.exists(app_exe):
        app_exe = os.path.join(target_dir, "ReupStudio_VIP.exe")
    if not os.path.exists(app_exe):
        app_exe = os.path.join(target_dir, "ReupStudio.exe")

    if show_dialog:
        msg = f"Đã cập nhật phiên bản mới nhất thành công!\n\nToàn bộ lỗi đã được sửa và tối ưu hóa hệ thống.\nBạn có muốn mở lại Xưởng Dowloader ngay không?"
        if ask_yes_no(APP_TITLE, msg):
            if os.path.exists(app_exe):
                subprocess.Popen([app_exe], cwd=target_dir)
    elif auto_restart and os.path.exists(app_exe):
        subprocess.Popen([app_exe], cwd=target_dir)

    return True

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Xuong Dowloader Remote OTA Updater")
    parser.add_argument("--url", help="Google Drive link or Direct Patch ZIP URL", default=None)
    parser.add_argument("--dir", help="Target installation directory", default=None)
    parser.add_argument("--no-gui", help="Disable graphical dialogs", action="store_true")
    parser.add_argument("--auto", help="Run unattended", action="store_true")
    args = parser.parse_args()

    run_update_process(
        target_dir=args.dir,
        patch_source=args.url,
        auto_restart=args.auto,
        show_dialog=not args.no_gui
    )
