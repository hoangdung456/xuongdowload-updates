"""
drama_downloader.platforms.reelshort
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Extractor for ReelShort platform (reelshort.com).
"""

import json
import re
from typing import Optional, List, Dict, Any
from .base import BasePlatform, GOODBOS_TOKEN
from ..models import Series, Episode, Subtitle, CatalogResult, CatalogItem


class ReelShortPlatform(BasePlatform):
    platform_id = "reelshort"
    display_name = "ReelShort"

    BASE_URL = "https://reelshort.goodbos.online"

    def can_handle(self, url: str) -> bool:
        u = url.lower().strip()
        return "reelshort" in u or u.startswith("reelshort:")

    def _extract_id(self, url: str) -> str:
        u = url.strip()
        m = re.search(r"reelshort:([0-9a-fA-F]{20,32})", u, re.I)
        if m:
            return m.group(1)
        m = re.search(r"([0-9a-fA-F]{24})", u)
        if m:
            return m.group(1)
        m = re.search(r"[?&]book_id=([0-9a-fA-F]+)", u, re.I)
        return m.group(1) if m else ""

    def load_series(self, url: str) -> Series:
        book_id = self._extract_id(url)
        if not book_id:
            raise ValueError(f"Could not extract ReelShort book ID from: {url}")

        name = "ReelShort Drama"
        cover = ""
        description = ""
        episodes: List[Episode] = []

        # 1. Fetch web Next.js metadata if web URL provided
        if "reelshort.com" in url:
            try:
                web_resp = self.http.get(url, headers={"User-Agent": "Mozilla/5.0"})
                if web_resp.status_code == 200:
                    m = re.search(r'<script[^>]*__NEXT_DATA__[^>]*>(.*?)</script>', web_resp.text)
                    if m:
                        d = json.loads(m.group(1))
                        page_data = d.get("props", {}).get("pageProps", {}).get("data", {})
                        name = page_data.get("book_title") or name
                        cover = page_data.get("book_pic") or cover
                        description = page_data.get("special_desc") or description
            except Exception:
                pass

        # 2. Fetch all chapters from Goodbos
        try:
            gb_url = f"{self.BASE_URL}/chapters/{book_id}?code={GOODBOS_TOKEN}"
            gb_resp = self.http.get(gb_url, headers={"User-Agent": "okhttp/4.10.0", "x-token": GOODBOS_TOKEN})
            if gb_resp.status_code == 200:
                gb_data = gb_resp.json()
                ch_list = gb_data.get("chapters", [])
                for idx, ch in enumerate(ch_list):
                    ep_num = idx + 1
                    ch_id = ch.get("id") or str(ep_num)
                    ep_name = ch.get("name") or f"Episode {ep_num}"
                    v_url = ch.get("video_url") or ch.get("cdn") or ch.get("mp4") or None
                    episodes.append(
                        Episode(
                            num=ep_num,
                            title=ep_name,
                            url=f"https://www.reelshort.com/movie/{book_id}/{ch_id}",
                            direct_url=v_url,
                            thumb=ch.get("video_pic") or cover,
                            locked=not bool(v_url),
                            extra={"chapter_id": ch_id, "duration": ch.get("duration", 0)},
                        )
                    )
        except Exception:
            pass

        return Series(
            name=name,
            platform=self.platform_id,
            series_id=f"reelshort:{book_id}",
            cover=cover,
            description=description,
            episode_count=len(episodes),
            accessible_count=sum(1 for ep in episodes if not ep.locked),
            episodes=episodes,
            url=url,
        )
