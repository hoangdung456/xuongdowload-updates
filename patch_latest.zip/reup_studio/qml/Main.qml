import QtQuick
import QtQuick.Controls.Material
import QtQuick.Layouts
import "components" as Comp

ApplicationWindow {
    id: root
    width: 1080; height: 660
    visible: true
    title: tr("app.title")
    color: theme.window
    Material.theme: Material.Light
    Material.accent: theme.accent

    property var currentLicense: null

    // Neon White & Cyan Theme (Màu xanh trắng neon)
    readonly property var neonTheme: ({
        window: "#edf5fb",
        bg: "#ffffff",
        surface: "#f7fbfe",
        elevated: "#ffffff",
        hover: "#e0f4ff",
        overlay: "#0b1a2cb0",
        borderSubtle: "#e1edf7",
        border: "#cfe2f3",
        borderStrong: "#00b4d8",
        borderFocus: "#0096e6",
        text: "#0a192f",
        textDim: "#2c4663",
        textMute: "#5f7d9c",
        textDisabled: "#9db2c7",
        textInverted: "#ffffff",
        accent: "#0096e6",
        accentHover: "#0077b6",
        accentPressed: "#005a8c",
        accentSoft: "#e0f7fe",
        accentMuted: "#33b1ff",
        accentText: "#ffffff",
        ok: "#059669",
        okSoft: "#e6f9f0",
        okBorder: "#a7f3d0",
        warn: "#d97706",
        warnSoft: "#fef3c7",
        warnBorder: "#fcd34d",
        danger: "#dc2626",
        dangerSoft: "#fee2e2",
        dangerBorder: "#fca5a5",
        info: "#0284c7",
        infoSoft: "#e0f2fe",
        infoBorder: "#bae6fd",
        rXs: 2, rSm: 4, rMd: 6, rLg: 8, rXl: 12, rXxl: 14, rFull: 9999,
        sXxs: 2, sXs: 4, sSm: 6, sMd: 8, sBase: 12, sLg: 16, sXl: 20, sXxl: 24, sXxxl: 32,
        hSm: 26, hMd: 30, hLg: 36, hBtnSm: 28, hBtnMd: 32, hBtnLg: 44, hMenuItem: 32, hChromeBar: 48,
        fPageTitle: 20, fSectionTitle: 17, fCardTitle: 15, fBodyLg: 14, fBody: 13, fLabel: 12, fLabelSm: 11, fCaption: 11
    })
    property var theme: neonTheme

    // i18n reactive wrapper (đọc lang → re-eval khi đổi ngôn ngữ)
    function tr(key) { var _ = i18n.lang; return i18n.t(key) }

    // ── nav model: [groupKey, [ [iconKey, navKey, pageIndex], ... ] ] ──
    property var navModel: [
        { group: "group.overview", items: [ {ic: "dashboard", key: "nav.dashboard", page: 0} ] },
        { group: "group.download", items: [ {ic: "download", key: "nav.download", page: 1},
                                            {ic: "store",    key: "nav.explore",  page: 11, gate: "explore"},
                                            {ic: "store",    key: "nav.store",    page: 2},
                                            {ic: "cart",     key: "nav.proxy",    page: 8},
                                            {ic: "settings", key: "nav.minitool", page: 9} ] },
        // thứ tự theo luồng người dùng: kết nối kênh → tạo luân chuyển → theo dõi hàng chờ → aff
        { group: "group.reup", gate: "reup", items: [ {ic: "channels", key: "nav.channels",  page: 5},
                                        {ic: "reup",     key: "nav.compose",   page: 10},
                                        {ic: "reup",     key: "nav.reup",      page: 3},
                                        {ic: "queue",    key: "nav.queue",     page: 4},
                                        {ic: "tag",      key: "nav.affiliate", page: 6} ] },
        { group: "group.other", items: [ {ic: "settings", key: "nav.settings", page: 7} ] }
    ]
    property int activePage: 1

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // ════ SIDEBAR ════
        Rectangle {
            Layout.preferredWidth: 210
            Layout.fillHeight: true
            color: theme.bg
            border.color: theme.borderSubtle

            ColumnLayout {
                anchors.fill: parent
                anchors.topMargin: 10
                spacing: 2

                Repeater {
                    model: root.navModel
                    delegate: ColumnLayout {
                        required property var modelData
                        Layout.fillWidth: true; spacing: 0
                        // group 'gate:reup' → chỉ hiện khi có quyền add-on REUP (MỞ KHÓA TOÀN BỘ)
                        visible: true
                        Text {
                            visible: parent.visible
                            text: tr(modelData.group).toUpperCase()
                            color: theme.textMute; font.pixelSize: 10
                            Layout.leftMargin: 16; Layout.topMargin: 12; Layout.bottomMargin: 4
                        }
                        Repeater {
                            model: modelData.items
                            delegate: ItemDelegate {
                                required property var modelData
                                Layout.fillWidth: true
                                // item có 'gate' → chỉ hiện khi có quyền (MỞ KHÓA TOÀN BỘ)
                                visible: true
                                height: visible ? 38 : 0
                                width: parent ? parent.width : 210
                                background: Rectangle {
                                    color: root.activePage === modelData.page ? theme.accentSoft : "transparent"
                                    Rectangle {  // accent bar trái khi active
                                        width: 3; height: parent.height
                                        color: root.activePage === modelData.page ? theme.accent : "transparent"
                                    }
                                }
                                contentItem: RowLayout {
                                    spacing: 10
                                    Item { width: 6 }
                                    Comp.NavIcon { iconKey: modelData.ic
                                        color: root.activePage === modelData.page ? theme.accent : theme.textDim }
                                    Text {
                                        text: tr(modelData.key)
                                        color: root.activePage === modelData.page ? theme.accent : theme.textDim
                                        font.bold: root.activePage === modelData.page
                                        font.pixelSize: 13
                                        Layout.fillWidth: true
                                    }
                                }
                                onClicked: root.activePage = modelData.page
                            }
                        }
                    }
                }
                Item { Layout.fillHeight: true }

                // ════ FOOTER sidebar: version + VI/EN + hạn dùng + đăng xuất ════
                Rectangle { Layout.fillWidth: true; height: 1; color: theme.borderSubtle }
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.margins: 10
                    spacing: 8

                    // hàng 1: version + (nút Cập nhật khi có bản mới) + toggle ngôn ngữ
                    RowLayout {
                        Layout.fillWidth: true; spacing: 8
                        Text {
                            text: "v.1.1.1"
                            color: theme.accent
                            font.pixelSize: 11
                            font.bold: true
                        }
                        // Nút Cập nhật từ xa một chạm (OTA)
                        Rectangle {
                            id: _updBtn
                            visible: true
                            radius: 999
                            color: _updMa.pressed ? theme.accent : (_updMa.containsMouse ? theme.accentMuted : theme.accentSoft)
                            border.color: theme.accentMuted; border.width: 1
                            implicitHeight: 22
                            implicitWidth: _updRow.implicitWidth + 16

                            property string btnText: "Cập nhật"

                            Row {
                                id: _updRow
                                anchors.centerIn: parent; spacing: 4
                                Comp.NavIcon { iconKey: "download"; size: 13; color: "#ffffff"
                                    anchors.verticalCenter: parent.verticalCenter }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: _updBtn.btnText
                                    color: theme.accent
                                    font.pixelSize: 11; font.bold: true
                                }
                            }
                            MouseArea {
                                id: _updMa; anchors.fill: parent; hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    _updBtn.btnText = "Đang mở..."
                                    var xhr = new XMLHttpRequest()
                                    xhr.open("GET", "http://127.0.0.1:8765/api/mock/ota-update")
                                    xhr.onreadystatechange = function() {
                                        if (xhr.readyState === XMLHttpRequest.DONE) {
                                            if (xhr.status === 200) {
                                                _updBtn.btnText = "Đang cập nhật..."
                                            } else {
                                                _updBtn.btnText = "Cập nhật"
                                            }
                                        }
                                    }
                                    xhr.send()
                                }
                            }
                        }
                        Item { Layout.fillWidth: true }
                        // VI / EN segmented
                        Rectangle {
                            radius: 4; color: theme.surface
                            border.color: theme.border; border.width: 1
                            implicitHeight: 24; implicitWidth: 56
                            Row {
                                anchors.fill: parent; anchors.margins: 2; spacing: 0
                                Repeater {
                                    model: [{l: "VI", v: "vi"}, {l: "EN", v: "en"}]
                                    delegate: Rectangle {
                                        required property var modelData
                                        width: parent.width / 2; height: parent.height
                                        radius: 3
                                        color: i18n.lang === modelData.v ? theme.accent : "transparent"
                                        Text {
                                            anchors.centerIn: parent; text: modelData.l
                                            color: i18n.lang === modelData.v ? "#ffffff" : theme.textDim
                                            font.pixelSize: 10; font.bold: true
                                        }
                                        MouseArea { anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: i18n.setLanguage(modelData.v) }
                                    }
                                }
                            }
                        }
                    }

                    // hàng 2: badge trạng thái bản quyền
                    RowLayout {
                        Layout.fillWidth: true; spacing: 8
                        visible: true
                        Rectangle {
                            Layout.fillWidth: true; implicitHeight: 34; radius: 6
                            color: (root.currentLicense && root.currentLicense.is_vip_build) ? "#e6f9f0" :
                                   (root.currentLicense && root.currentLicense.days_left <= 3 ? "#fffbeb" : "#f0f8ff")
                            border.color: (root.currentLicense && root.currentLicense.is_vip_build) ? theme.ok :
                                          (root.currentLicense && root.currentLicense.days_left <= 3 ? "#f59e0b" : "#bce3f7")
                            border.width: 1
                            ColumnLayout {
                                anchors.centerIn: parent; spacing: 1
                                Text {
                                    Layout.alignment: Qt.AlignHCenter
                                    text: (root.currentLicense && root.currentLicense.is_vip_build) ? "★ PRO VIP VĨNH VIỄN" :
                                          (root.currentLicense && root.currentLicense.customer_name ? ("👤 " + root.currentLicense.customer_name) : "BẢN QUYỀN THƯƠNG MẠI")
                                    color: (root.currentLicense && root.currentLicense.is_vip_build) ? "#059669" : "#0077b6"
                                    font.pixelSize: 10; font.bold: true
                                }
                                Text {
                                    Layout.alignment: Qt.AlignHCenter
                                    text: (root.currentLicense && root.currentLicense.is_vip_build) ? "Đã Kích Hoạt" :
                                          (root.currentLicense && root.currentLicense.expiry ? ("⏳ " + root.currentLicense.expiry + (root.currentLicense.days_left < 9999 ? (" (" + root.currentLicense.days_left + " ngày)") : "")) : "Chưa kích hoạt")
                                    color: (root.currentLicense && root.currentLicense.days_left <= 3 && !root.currentLicense.is_vip_build) ? "#d97706" : "#64748b"
                                    font.pixelSize: 9; font.bold: true
                                }
                            }
                        }
                    }
                }
            }
        }

        // ════ CONTENT ════
        ColumnLayout {
            Layout.fillWidth: true; Layout.fillHeight: true; spacing: 0

            // (bỏ topbar — sidebar đã chỉ rõ trang active; mỗi page tự có tiêu đề riêng)
            StackLayout {
                Layout.fillWidth: true; Layout.fillHeight: true
                currentIndex: root.activePage
                Placeholder { name: tr("nav.dashboard"); iconKey: "dashboard"
                    desc: tr("page.dashboard_desc") }                                    // 0
                DownloadPage { id: downloadPage }                                        // 1
                StorePage {}                                                             // 2
                MappingPage {}                                                           // 3
                QueuePage {}                                                             // 4
                ChannelsPage {}                                                          // 5
                AffiliatePage {}                                                         // 6
                SettingsPage {}                                                          // 7
                ProxyDownloadPage { isActive: root.activePage === 8 }                    // 8 (Tải hộ)
                MiniToolPage {}                                                          // 9 (Công cụ)
                ComposePage {}                                                           // 10 (Soạn bài)
                ExplorePage {}                                                           // 11 (Khám phá)
            }
        }
    }

    // Khám phá → Tải: click "Tải phim này" ở popup detail → chuyển tab Tải + nạp link + quét
    Connections {
        target: exploreVM
        function onFilmPicked(seriesId, url) {
            root.activePage = 1            // sang màn Tải video
            downloadPage.loadUrl(url)
        }
    }

    // Login gate — VÔ HIỆU HÓA
    LoginOverlay { anchors.fill: parent; visible: false; enabled: false }

    // Auto-update — VÔ HIỆU HÓA
    UpdateModal { id: updateModal; visible: false; enabled: false }

    // Bản quyền thiết bị — Hiển thị kích hoạt đối với bản Khách Hàng (tự ẩn đối với bản VIP)
    ActivationOverlay {
        id: actOverlay
        anchors.fill: parent
        onLicenseUpdated: function(lic) {
            root.currentLicense = lic
        }
    }

    function _titleFor(p) {
        var map = ["nav.dashboard","nav.download","nav.store","nav.reup",
                   "nav.queue","nav.channels","nav.affiliate","nav.settings","nav.proxy","nav.minitool","nav.compose","nav.explore"]
        return tr(map[p])
    }
}
