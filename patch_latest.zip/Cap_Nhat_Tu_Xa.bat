@echo off
setlocal
cd /d "%~dp0"
title Xuong Dowloader - Cap Nhat Tu Xa

REM Kiem tra quyen Administrator
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Dang yeu cau quyen Administrator de cap nhat...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo ==================================================================
echo         XUONG DOWLOADER - CAP NHAT TU XA (OTA GITHUB)
echo ==================================================================
echo.

set "PY_EXE="
if exist "%~dp0engine\python\python.exe" set "PY_EXE=%~dp0engine\python\python.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY_EXE if exist "%~dp0python.exe" set "PY_EXE=%~dp0python.exe"
if not defined PY_EXE if exist "%~dp0reup_engine.exe" set "PY_EXE=%~dp0reup_engine.exe"
if not defined PY_EXE set "PY_EXE=python"

"%PY_EXE%" "%~dp0ota_updater.py" %*

if %errorlevel% equ 0 (
    echo.
    echo [THANH CONG] Tien trinh cap nhat hoan tat!
) else (
    echo.
    echo [LOI] Qua trinh cap nhat gap su co hoac da bi huy.
)

echo.
echo Nhan phim bat ky de thoat...
pause >nul
