@echo off
chcp 65001 >nul
title XƯỞNG DOWLOADER - CẬP NHẬT TỪ XA MỘT CHẠM

:: Kiểm tra quyền Administrator và tự động kích hoạt UAC nếu cần
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Đang kích hoạt quyền Quản trị viên (Administrator)...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ==================================================================
echo         XƯỞNG DOWLOADER - CẬP NHẬT TỪ XA MỘT CHẠM (OTA)
echo ==================================================================
echo.

:: Tìm Python runtime
set "PY_EXE="
if exist "%~dp0reup_engine.exe" set "PY_EXE=%~dp0reup_engine.exe"
if not defined PY_EXE if exist "%~dp0python.exe" set "PY_EXE=%~dp0python.exe"
if not defined PY_EXE if exist "C:\Program Files (x86)\Xuong Dowloader VIP\reup_engine.exe" set "PY_EXE=C:\Program Files (x86)\Xuong Dowloader VIP\reup_engine.exe"
if not defined PY_EXE if exist "C:\Program Files (x86)\Xuong Dowloader\reup_engine.exe" set "PY_EXE=C:\Program Files (x86)\Xuong Dowloader\reup_engine.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY_EXE set "PY_EXE=python"

"%PY_EXE%" "%~dp0ota_updater.py" %*

if %errorLevel% equ 0 (
    echo.
    echo [SUCCESS] Tiến trình cập nhật hoàn tất!
) else (
    echo.
    echo [ERROR] Quá trình cập nhật gặp sự cố hoặc đã bị hủy.
)

echo.
echo Nhấn phím bất kỳ để thoát...
pause >nul
