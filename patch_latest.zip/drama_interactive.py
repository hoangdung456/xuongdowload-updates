"""
Interactive Short Drama & Subtitle Downloader for ReupStudio
Supports 12 OTT platforms:
DramaBox, GoodShort, ShortMax, NetShort, FreeReels, KissKH,
Hongguo, DramaWave, FlexTV, RaptDrama, StardustTV, ReelShort
Features:
- Parallel multi-thread downloading (concurrency 1-10)
- Automatic VIP & locked episode unlocking
- Subtitle extraction & conversion (WebVTT -> SubRip .SRT)
- Range downloading (e.g. 1-10, 15, 20)
- Drama Catalog explorer & search
"""

import os
import sys
import time
import re
from concurrent.futures import ThreadPoolExecutor

try:
    if sys.stdout.encoding.lower() != "utf-8":
        sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

DEFAULT_OUT_DIR = r"D:\Downloads\PhimNgan"
if not os.path.exists(r"D:\Downloads"):
    DEFAULT_OUT_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "PhimNgan")

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def print_header():
    print("=" * 68)
    print("     XƯỞNG DOWNLOADER - BỘ CÔNG CỤ TẢI PHIM NGẮN & PHỤ ĐỀ VIP PRO")
    print("  Hỗ trợ 12 nền tảng: DramaBox, GoodShort, ShortMax, NetShort, FreeReels,")
    print("                      KissKH, Hongguo, DramaWave, FlexTV, RaptDrama,")
    print("                      StardustTV, ReelShort")
    print("  Tính năng: Tự động mở khóa tập VIP + Tải đa luồng + Xuất Sub (.SRT)")
    print("=" * 68)
    print()

def unlock_all_episodes(series):
    import drama_downloader.platforms as ddp
    needing_unlock = [ep for ep in series.episodes if not ep.direct_url]
    if needing_unlock:
        print(f"[*] Đang tự động mở khóa {len(needing_unlock)} tập phim (Bypass Paywall VIP)...")
        def _unlock(ep):
            try:
                v = ddp.get_video_url(ep, platform_hint=series.platform)
                if v:
                    ep.direct_url = v
                    ep.locked = False
            except Exception:
                pass
            return ep
        worker_count = min(12, max(2, len(needing_unlock)))
        with ThreadPoolExecutor(max_workers=worker_count) as pool:
            list(pool.map(_unlock, needing_unlock))

def download_series_flow(target, output_dir=None, concurrency=4, save_vtt=False):
    import drama_downloader.platforms as ddp
    from drama_downloader.downloader import DramaDownloader
    from drama_downloader.cli import parse_range

    print(f"\n[*] Đang kết nối và phân tích liên kết: {target}")
    series = ddp.load_series(target)
    if not series or not series.episodes:
        print("[!] Không tìm thấy tập phim nào từ đường dẫn này.")
        return

    unlock_all_episodes(series)

    print("-" * 68)
    print(f"Tên phim:    {series.name}")
    print(f"Nền tảng:    {series.platform.upper()}")
    accessible_count = sum(1 for ep in series.episodes if ep.direct_url)
    print(f"Tổng số tập: {len(series.episodes)} tập (Đã mở khóa: {accessible_count}/{len(series.episodes)} tập)")
    if series.cover:
        print(f"Ảnh bìa:     {series.cover}")
    subs_total = sum(len(ep.subs) for ep in series.episodes)
    print(f"Phụ đề kèm:  {subs_total} file phụ đề (tự động chuyển đổi thành file .SRT chuẩn)")
    print("-" * 68)
    print()

    print("Chọn chế độ tải:")
    print("  1. Tải toàn bộ tất cả các tập (100% full series + phụ đề .srt)")
    print("  2. Tải theo khoảng tập tùy chọn (ví dụ: 1-10 hoặc 1,5,10-20)")
    print("  3. Xem chi tiết danh sách tập & trạng thái luồng video")
    print("  4. Quay lại menu chính")
    print()

    opt = input(">> Lựa chọn (1-4, mặc định 1): ").strip() or "1"
    if opt == "4":
        return
    elif opt == "3":
        print("\nDanh sách chi tiết các tập:")
        for ep in series.episodes:
            st = "[ĐÃ MỞ KHÓA]" if ep.direct_url else ("[KHÓA VIP]" if ep.locked else "[OK]")
            sub_str = f" ({len(ep.subs)} phụ đề)" if ep.subs else ""
            print(f"  Tập {ep.num:03d}: {ep.title} {st}{sub_str}")
        input("\nNhấn Enter để tiếp tục tải...")
        return download_series_flow(target, output_dir=output_dir, concurrency=concurrency, save_vtt=save_vtt)

    range_filter = None
    if opt == "2":
        r_str = input(f">> Nhập dải tập (từ 1 đến {len(series.episodes)}, ví dụ: 1-20 hoặc 1,3,5): ").strip()
        if r_str:
            try:
                range_filter = parse_range(r_str, len(series.episodes))
                print(f"[*] Sẽ tải {len(range_filter)} tập: {range_filter[:10]}...")
            except Exception as e:
                print(f"[!] Dải tập không hợp lệ: {e}. Sẽ tải tất cả tập.")

    target_dir = output_dir or DEFAULT_OUT_DIR
    os.makedirs(target_dir, exist_ok=True)
    custom_dir = input(f">> Thư mục lưu [{target_dir}]: ").strip()
    if custom_dir:
        target_dir = custom_dir
        os.makedirs(target_dir, exist_ok=True)

    threads_input = input(f">> Số luồng tải song song [1-10, mặc định {concurrency}]: ").strip()
    workers = int(threads_input) if (threads_input.isdigit() and 1 <= int(threads_input) <= 10) else concurrency

    dl = DramaDownloader(output_dir=target_dir, concurrency=workers, save_vtt=save_vtt)

    print(f"\n[*] Bắt đầu tải đa luồng ({workers} workers) vào: {target_dir}")
    print("[*] Đang tải video và tự động chuyển đổi phụ đề sang .SRT...")
    start_t = time.time()

    def on_done(ep, path):
        sub_info = f" (+ {len(ep.subs)} sub SRT)" if ep.subs else ""
        print(f"  [✔] XONG: Tập {ep.num:02d} -> {os.path.basename(path)}{sub_info}")

    def on_err(ep, err):
        print(f"  [x] LỖI: Tập {ep.num:02d} -> {err}")

    completed = dl.download_series(
        series,
        episodes_range=range_filter,
        on_episode_done=on_done,
        on_episode_error=on_err
    )

    elapsed = time.time() - start_t
    print()
    print("=" * 68)
    print(f"[THÀNH CÔNG] Đã tải hoàn tất {len(completed)} tập trong {elapsed:.1f} giây!")
    print(f"[LƯU Ý] Toàn bộ video (.mp4) và phụ đề chuẩn (.srt) đã lưu tại:")
    print(f"        {os.path.join(target_dir, series.name)}")
    print("=" * 68)
    input("\nNhấn Enter để quay lại...")

def catalog_flow():
    import drama_downloader.platforms as ddp
    clear()
    print_header()
    print("--- KHÁM PHÁ DANH MỤC PHIM NGẮN (CATALOG & SEARCH) ---")
    print("Chọn nền tảng duyệt phim:")
    print("  1. DramaBox")
    print("  2. ShortMax")
    print("  3. KissKH")
    print("  4. FreeReels")
    print("  0. Quay lại")
    print()

    choice = input(">> Chọn nền tảng (1-4, 0 thoát): ").strip()
    plat_map = {"1": "dramabox", "2": "shortmax", "3": "kisskh", "4": "freereels"}
    plat_id = plat_map.get(choice)
    if not plat_id:
        return

    platform = ddp.get_platform(plat_id)
    if not platform:
        print(f"[!] Nền tảng {plat_id} chưa hỗ trợ xem catalog.")
        input("Nhấn Enter để tiếp tục...")
        return

    query = input(">> Nhập từ khóa tìm kiếm (Enter để xem phim hot/mới nhất): ").strip() or None
    page_str = input(">> Số trang [mặc định 1]: ").strip()
    page = int(page_str) if page_str.isdigit() else 1

    print(f"\n[*] Đang tải danh sách phim từ {platform.display_name}...")
    try:
        res = platform.get_catalog(page=page, query=query)
        if not res or not res.items:
            print("[!] Không tìm thấy phim nào phù hợp.")
            input("\nNhấn Enter để tiếp tục...")
            return

        print("\n" + "=" * 68)
        print(f"DANH SÁCH PHIM {platform.display_name.upper()} (Tổng: {res.total} phim)")
        print("=" * 68)
        for idx, item in enumerate(res.items):
            ep_info = f"({item.episodes} tập)" if item.episodes else ""
            print(f"  [{idx + 1:02d}] {item.name} {ep_info}")
            if item.link:
                print(f"       Link: {item.link}")
        print("=" * 68)

        sel = input("\n>> Nhập số thứ tự phim để tải ngay (hoặc Enter để quay lại): ").strip()
        if sel.isdigit() and 1 <= int(sel) <= len(res.items):
            chosen = res.items[int(sel) - 1]
            if chosen.link:
                download_series_flow(chosen.link)
    except Exception as e:
        print(f"[!] Lỗi khi lấy danh mục: {e}")
        input("\nNhấn Enter để tiếp tục...")

def show_platforms():
    import drama_downloader.platforms as ddp
    clear()
    print_header()
    print("--- 12 NỀN TẢNG PHIM NGẮN ĐƯỢC HỖ TRỢ HOÀN CHỈNH ---")
    platforms = ddp.get_all_platforms()
    for idx, p in enumerate(platforms, 1):
        print(f"  {idx:02d}. {p.display_name:<16} (ID: {p.platform_id:<12}) -> [SẴN SÀNG]")
    print("-" * 68)
    print("Tất cả nền tảng đều hỗ trợ:")
    print("  + Bóc tách danh sách tập đầy đủ")
    print("  + Mở khóa tập VIP / Paywall tự động")
    print("  + Trích xuất & chuyển đổi phụ đề (.SRT / .VTT)")
    print("  + Tải đa luồng song song tốc độ cao")
    print("=" * 68)
    input("\nNhấn Enter để quay lại...")

def main():
    while True:
        clear()
        print_header()
        print("MENU CHỨC NĂNG CHÍNH:")
        print("  1. Dán Link / ID phim để Quét & Tải Full tập (Kể cả tập khóa VIP)")
        print("  2. Khám phá & Tìm kiếm danh mục phim (Catalog Explorer)")
        print("  3. Xem danh sách 12 nền tảng hỗ trợ & trạng thái hoạt động")
        print("  0. Thoát")
        print()

        cmd = input(">> Nhập lựa chọn của bạn (0-3): ").strip()
        if cmd == "1":
            target = input("\n>> Nhập link phim (URL) hoặc ID phim: ").strip()
            if target:
                download_series_flow(target)
        elif cmd == "2":
            catalog_flow()
        elif cmd == "3":
            show_platforms()
        elif cmd == "0":
            print("\nCảm ơn bạn đã sử dụng Xưởng Downloader! Tạm biệt.")
            break

if __name__ == "__main__":
    main()
