@echo off
title Tai Phim Ngan & Phu De - Reup Studio
cd /d "%~dp0"

:: Tim Python executable phu hop
set PY_EXE=
if exist "%CD%\engine\python\python.exe" (
    set "PY_EXE=%CD%\engine\python\python.exe"
) else if exist "C:\Users\HoangDung\AppData\Local\Programs\Python\Python312\python.exe" (
    set "PY_EXE=C:\Users\HoangDung\AppData\Local\Programs\Python\Python312\python.exe"
) else (
    set "PY_EXE=py -3.12"
)

"%PY_EXE%" drama_interactive.py
pause
