import os
import sys
import json
import base64
import time

sys.stdout.reconfigure(encoding="utf-8")
REAL_STDOUT = sys.stdout
sys.stdout = sys.stderr

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if sys.version_info[:2] == (3, 11):
    sys.path = [p for p in sys.path if os.path.abspath(p) != os.path.abspath(BASE_DIR)]
    engine_python_lib = os.path.join(BASE_DIR, "engine", "python")
    if os.path.exists(engine_python_lib) and engine_python_lib not in sys.path:
        sys.path.insert(0, engine_python_lib)

LOCAL_APP_DIR = os.path.join(BASE_DIR, "engine", "app")
LOCALAPPDATA = os.environ.get("LOCALAPPDATA", "")
FALLBACK_APP_DIR = os.path.join(LOCALAPPDATA, "Programs", "Hongguo Downloader", "app") if LOCALAPPDATA else ""
APP_DIR = LOCAL_APP_DIR if os.path.exists(LOCAL_APP_DIR) else FALLBACK_APP_DIR
import ctypes
import subprocess
import requests

def _query_process_token():
    kernel32 = ctypes.windll.kernel32
    ntdll = ctypes.windll.ntdll
    class PBI(ctypes.Structure):
        _fields_ = [("ExitStatus", ctypes.c_ulonglong), ("PebBaseAddress", ctypes.c_void_p),
                    ("AffinityMask", ctypes.c_ulonglong), ("BasePriority", ctypes.c_ulonglong),
                    ("UniqueProcessId", ctypes.c_ulonglong), ("InheritedFromUniqueProcessId", ctypes.c_ulonglong)]

    try:
        out = subprocess.check_output(['wmic', 'process', 'where', "CommandLine like '%server.pyc%' or CommandLine like '%app.pyc%'", 'get', 'ProcessId'], text=True)
        pids = [int(p.strip()) for p in out.splitlines() if p.strip().isdigit()]
        for pid in pids:
            h = kernel32.OpenProcess(0x0410, False, pid)
            if not h: continue
            pbi = PBI()
            ret_len = ctypes.c_ulong()
            if ntdll.NtQueryInformationProcess(h, 0, ctypes.byref(pbi), ctypes.sizeof(pbi), ctypes.byref(ret_len)) == 0:
                buf = ctypes.c_void_p()
                bread = ctypes.c_size_t()
                kernel32.ReadProcessMemory(h, ctypes.c_void_p(pbi.PebBaseAddress + 0x20), ctypes.byref(buf), 8, ctypes.byref(bread))
                env_ptr = ctypes.c_void_p()
                kernel32.ReadProcessMemory(h, ctypes.c_void_p(buf.value + 0x80), ctypes.byref(env_ptr), 8, ctypes.byref(bread))
                env_data = ctypes.create_string_buffer(65536)
                kernel32.ReadProcessMemory(h, env_ptr, env_data, 65536, ctypes.byref(bread))
                raw_env = bytes(env_data[:bread.value])
                strings = raw_env.decode('utf-16le', errors='ignore').split('\0')
                for s in strings:
                    if s.startswith('HG_SIGN_TOKEN='):
                        tok = s.split('=', 1)[1].strip()
                        kernel32.CloseHandle(h)
                        return tok
            kernel32.CloseHandle(h)
    except Exception:
        pass
    return None

def get_signer_token():
    # 1. Test if already responding
    for test_tok in [None, "secret123"]:
        try:
            h = {"X-Sign-Token": test_tok} if test_tok else {}
            r = requests.post("http://127.0.0.1:9099/sign", json={"url": "https://example.com"}, headers=h, timeout=0.8)
            if r.status_code == 200:
                return test_tok or ""
        except Exception:
            pass

    # 2. Check running process
    tok = _query_process_token()
    if tok:
        try:
            r = requests.post("http://127.0.0.1:9099/sign", json={"url": "https://example.com"}, headers={"X-Sign-Token": tok}, timeout=0.8)
            if r.status_code == 200:
                return tok
        except Exception:
            pass

    # 3. Auto-start Java signer
    jre = os.path.join(BASE_DIR, "engine", "jre", "bin", "java.exe")
    if not os.path.exists(jre) and LOCALAPPDATA:
        jre = os.path.join(LOCALAPPDATA, "Programs", "Hongguo Downloader", "jre", "bin", "java.exe")
    sign_dir = os.path.join(BASE_DIR, "engine", "app", "sign")
    if not os.path.exists(sign_dir) and LOCALAPPDATA:
        sign_dir = os.path.join(LOCALAPPDATA, "Programs", "Hongguo Downloader", "app", "sign")
    jar = os.path.join(sign_dir, "unidbg-sign.jar")

    if os.path.exists(jre) and os.path.exists(jar):
        cmd = [
            jre,
            "-Xmx1024m",
            "-XX:+ExitOnOutOfMemoryError",
            "--add-opens",
            "java.base/java.lang=ALL-UNNAMED",
            "-cp",
            "unidbg-sign.jar",
            "com.hongguo.sign.FqTrace",
            "serve",
            "9099"
        ]
        s_env = os.environ.copy()
        s_env["HG_SIGN_TOKEN"] = "secret123"
        try:
            flags = (subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP) if sys.platform == "win32" else 0
            subprocess.Popen(
                cmd,
                cwd=sign_dir,
                env=s_env,
                creationflags=flags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            for _ in range(30):
                time.sleep(0.3)
                try:
                    r = requests.post("http://127.0.0.1:9099/sign", json={"url": "https://example.com"}, headers={"X-Sign-Token": "secret123"}, timeout=0.5)
                    if r.status_code == 200:
                        return "secret123"
                except Exception:
                    pass
        except Exception as e:
            sys.stderr.write(f"Failed to start Java signer: {e}\n")

    return "secret123"

os.environ["SIGN_SERVER"] = "http://127.0.0.1:9099"
os.environ["HG_SIGN_TOKEN"] = get_signer_token()
sys.path.insert(0, APP_DIR)
sys.path.insert(0, os.path.join(APP_DIR, "frida"))

try:
    import hongguo
except Exception as e:
    sys.stderr.write(f"Failed to import hongguo: {e}\n")
    print(json.dumps({"ok": False, "message": str(e)}))
    sys.exit(1)

for _p in [
    os.path.join(BASE_DIR, "engine", "app", "frida"),
    os.path.join(APP_DIR, "frida") if APP_DIR else "",
    os.path.join(BASE_DIR, "engine", "app"),
    BASE_DIR,
    os.path.dirname(os.path.abspath(__file__)),
]:
    if _p and os.path.exists(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

try:
    import unwrap_spade
except Exception as e:
    sys.stderr.write(f"Warning: could not import unwrap_spade: {e}\n")
    unwrap_spade = None

from concurrent.futures import ThreadPoolExecutor

def handle_grab(params):
    series_id = str(params.get("series_id", "")).strip()
    limit = int(params.get("limit") or 0)
    if not series_id:
        return {"ok": False, "message": "missing series_id"}

    try:
        meta, eps = hongguo.get_episodes(series_id)
        if not eps:
            return {"ok": False, "message": "no episodes found"}

        if limit and len(eps) > limit:
            eps = eps[:limit]

        series_title = meta.get("title", f"Phim {series_id}")
        create_time = meta.get("create_time") or 1700000000
        try:
            pub_time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(create_time)))
        except Exception:
            pub_time_str = "2024-01-01 00:00:00"

        vids = [str(ep.get("vid")) for ep in eps if ep.get("vid")]

        # High-speed resolution using rotating unsigned device identities (bypasses 110001 & device expiry)
        resolved_urls = {}
        VIDEO_MODEL_API = "https://api5-normal-sinfonlineb.fqnovel.com/novel/player/multi_video_model/v1/"
        VIDEO_UA = "com.phoenix.read/71332 (Linux; U; Android 16; zh_CN; 25053RT47C; Build/BP2A.250605.031.A3; Cronet/TTNetVersion:04657795 2026-01-23 QuicVersion:c67e9834 2025-09-08)"

        DEVICE_TEMPLATE = {
            "ac": "wifi", "channel": "update_64", "aid": "8662", "app_name": "novelread",
            "version_code": "71332", "version_name": "7.1.3.32", "device_platform": "android",
            "os": "android", "ssmix": "a", "device_type": "25053RT47C", "device_brand": "Redmi",
            "language": "zh", "os_api": "36", "os_version": "16", "manifest_version_code": "71332",
            "resolution": "1280*2772", "dpi": "520", "update_version_code": "71332",
            "host_abi": "arm64-v8a", "dragon_device_type": "phone", "pv_player": "71332",
            "compliance_status": "0", "need_personal_recommend": "1", "player_so_load": "1",
            "is_android_pad_screen": "0"
        }

        import random
        def gen_numeric_id():
            return str(random.randint(100000000000000000, 999999999999999999))

        batches = [[v] for v in vids]

        sess = requests.Session()
        adapter = requests.adapters.HTTPAdapter(pool_connections=16, pool_maxsize=32)
        sess.mount("https://", adapter)

        def fetch_video_batch(b):
            res_map = {}
            try:
                d = dict(DEVICE_TEMPLATE)
                d["iid"] = gen_numeric_id()
                d["device_id"] = gen_numeric_id()
                d["cdid"] = gen_numeric_id()
                now_ms = int(time.time() * 1000)
                d["ts"] = str(int(now_ms / 1000))
                d["_rticket"] = str(now_ms)

                headers = {
                    "User-Agent": VIDEO_UA,
                    "Accept": "application/json; charset=utf-8,application/x-protobuf",
                    "x-ss-req-ticket": str(now_ms),
                    "x-tt-request-tag": "t=0;n=0",
                    "sdk-version": "2",
                    "x-xs-from-web": "0",
                    "Content-Type": "application/json; charset=UTF-8"
                }
                body = {
                    "biz_param": {
                        "detail_page_version": 0, "device_level": 3, "disable_digg_stat": False,
                        "need_all_video_definition": True, "need_mp4_align": False, "use_os_player": False,
                        "use_server_dns": False, "video_platform": 1024
                    },
                    "mixed_video_id_map": {"1004": b}
                }
                resp = sess.post(VIDEO_MODEL_API, params=d, headers=headers, json=body, timeout=7)
                if resp.status_code == 200:
                    data = resp.json().get("data", {})
                    for v_id, item in data.items():
                        vm_str = item.get("video_model")
                        if not vm_str:
                            continue
                        vm = json.loads(vm_str) if isinstance(vm_str, str) else vm_str
                        v_list = vm.get("video_list", [])
                        if not v_list:
                            continue
                        best = max(v_list, key=lambda it: (it.get("video_meta", {}).get("size", 0) or 0), default=None)
                        if best:
                            enc = best.get("encrypt_info") or {}
                            spade_a = enc.get("spade_a") or ""
                            kid = enc.get("kid") or ""
                            key = ""
                            if spade_a and unwrap_spade:
                                try:
                                    key = unwrap_spade.spade_to_key(spade_a)
                                except Exception:
                                    pass
                            if not key or len(key) != 32:
                                key = "00" * 16
                            dl_url = best.get("main_url") or best.get("backup_url") or ""
                            defn = best.get("video_meta", {}).get("definition", "1080p")
                            res_map[str(v_id)] = {
                                "url": dl_url,
                                "aes_key": key,
                                "kid": kid,
                                "definition": defn
                            }
            except Exception as e:
                sys.stderr.write(f"Video resolution batch error: {e}\n")
            return res_map

        with ThreadPoolExecutor(max_workers=12) as pool:
            for r in pool.map(fetch_video_batch, batches):
                if r:
                    resolved_urls.update(r)

        formatted_eps = []
        for ep in eps:
            vid = str(ep.get("vid"))
            idx = ep.get("index", 1)
            title = ep.get("title") or f"Tập {idx:02d}"

            u_info = resolved_urls.get(vid, {})
            video_url = u_info.get("url") or ""
            aes_key = u_info.get("aes_key") or ("00" * 16)
            kid = u_info.get("kid") or ""
            defn = u_info.get("definition") or "1080p"

            # Fallback to public web URL if preload missed
            if not video_url:
                video_url = f"https://hongguoduanju.com/video/public/{vid}/360p.mp4"

            ep_cover = ep.get("cover") or ep.get("cover_url") or meta.get("cover") or ""
            film_cover = meta.get("cover") or ep_cover

            formatted_eps.append({
                "index": idx,
                "title": f"{series_title} - Tập {idx:02d}" if "Tập" not in title else title,
                "item_id": str(vid),
                "duration": int(ep.get("duration") or 0),
                "poster": ep_cover,
                "cover": ep_cover,
                "cover_url": ep_cover,
                "cdn_url": video_url,
                "aes_key": aes_key,
                "kid": kid,
                "publish_time": pub_time_str,
                "definition": defn,
                "codec": "h264",
                "width": 1080,
                "height": 1920
            })

        return {
            "ok": True,
            "film": {
                "title": series_title,
                "intro": meta.get("intro", ""),
                "cover": film_cover,
                "cover_url": film_cover,
                "total": len(formatted_eps)
            },
            "series": {
                "title": series_title,
                "abstract": meta.get("intro", ""),
                "cover": film_cover,
                "cover_url": film_cover,
                "episode_cnt": len(formatted_eps),
                "status": meta.get("status", "完结"),
                "score": str(meta.get("score") or "9.8"),
                "category": meta.get("category", [])
            },
            "episodes": formatted_eps
        }
    except Exception as e:
        sys.stderr.write(f"Grab exception: {e}\n")
        return {"ok": False, "message": str(e)}

def handle_search(params):
    q = params.get("key") or ""
    if not q and params.get("key_b64"):
        try:
            q = base64.b64decode(params.get("key_b64")).decode("utf-8")
        except Exception:
            pass
    limit = int(params.get("limit") or 20)
    try:
        raw_results = hongguo.search(q, max_items=limit)
        results = []
        for r in (raw_results or []):
            sid = str(r.get("series_id") or r.get("id") or "")
            results.append({
                "series_id": sid,
                "title": r.get("title", ""),
                "url": f"https://hongguoduanju.com/detail?series_id={sid}",
                "cover": r.get("cover", ""),
                "episodes": r.get("episode_cnt", 0),
                "score": str(r.get("score") or "9.8"),
                "category": "/".join(r.get("category", [])) if isinstance(r.get("category"), list) else str(r.get("category") or ""),
                "view_text": str(r.get("play_cnt") or ""),
                "desc": r.get("intro", ""),
                "sub_title": r.get("status", "")
            })
        return {"ok": True, "results": results}
    except Exception as e:
        return {"ok": False, "message": str(e), "results": []}

def handle_feed(params):
    genre = params.get("genre", "all")
    sort = params.get("sort", "hot")
    offset = int(params.get("offset") or 0)
    limit = int(params.get("limit") or 20)
    try:
        if sort == "latest":
            raw_items = hongguo.latest(max_items=limit)
        else:
            raw_items = hongguo.rank("hot", limit=limit)
        items = []
        for it in (raw_items or []):
            sid = str(it.get("series_id") or it.get("id") or "")
            items.append({
                "series_id": sid,
                "title": it.get("title", ""),
                "cover": it.get("cover", ""),
                "sub_title": it.get("status", "") or f"{it.get('episode_cnt', 0)} tập",
                "desc": it.get("intro", ""),
                "play_cnt": str(it.get("play_cnt") or ""),
                "hot_text": str(it.get("score") or "Hot"),
                "is_today": bool(it.get("today")),
                "is_new": False,
                "status": "完结",
                "last_publish": ""
            })
        return {
            "ok": True,
            "items": items,
            "next_offset": offset + limit,
            "has_more": True
        }
    except Exception as e:
        return {"ok": True, "items": [], "has_more": False}


def handle_detail(params):
    series_id = str(params.get("series_id", "")).strip()
    try:
        meta, eps = hongguo.get_episodes(series_id)
        return {
            "ok": True,
            "series": {
                "title": meta.get("title", ""),
                "abstract": meta.get("intro", ""),
                "cover": meta.get("cover", ""),
                "episode_cnt": len(eps),
                "status": meta.get("status", ""),
                "score": str(meta.get("score") or "9.8"),
                "category": meta.get("category", [])
            }
        }
    except Exception as e:
        return {"ok": False, "message": str(e)}

def main():
    try:
        raw_in = sys.stdin.read()
        if not raw_in.strip():
            return
        data = json.loads(raw_in)
        action = data.get("action")
        params = data.get("params", {})

        if action == "hongguo-grab":
            res = handle_grab(params)
        elif action == "hongguo-search":
            res = handle_search(params)
        elif action == "hongguo-feed":
            res = handle_feed(params)
        elif action == "hongguo-detail":
            res = handle_detail(params)
        else:
            res = {"ok": False, "message": f"unknown action {action}"}

        REAL_STDOUT.write(json.dumps(res, ensure_ascii=False) + "\n")
        REAL_STDOUT.flush()
    except Exception as e:
        REAL_STDOUT.write(json.dumps({"ok": False, "message": str(e)}) + "\n")
        REAL_STDOUT.flush()

if __name__ == "__main__":
    main()
